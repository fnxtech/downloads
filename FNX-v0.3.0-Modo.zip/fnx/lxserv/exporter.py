# Python
import shutil
import math

# Modo
import lx, lxu, modo

# FNX
from fnx import constants

# plugin-libs
from fnx.plugin_libs.logger import get_logger
from fnx.plugin_libs import utils as pl_utils
from fnx.plugin_libs import exceptions as pl_exceptions
from fnx.plugin_libs.externals.pathlib2 import Path

LOGGER = get_logger(__name__)


class CustomRenderChannelContext:

    def __init__(self, channels):
        self._channels_to_edit = channels
        self._channel_settings = {}

    def __enter__(self):
        # Cache values
        for channel in self._channels_to_edit:
            self._channel_settings[channel] = modo.Scene().renderItem.channel(channel).get()

    def __exit__(self, _type, _value, _traceback):
        for channel_name, channel_value in self._channel_settings.items():
            modo.Scene().renderItem.channel(channel_name).set(channel_value)


def render_camera_views(output_dir):
    """
    Render custom camera views and generate dictionary with camera transformation data.

    Blender custom camera dictionary will have the following format:

        {
          "name": "FNX_CAMERA__test",
          "image_path": "C:\\Users\\DOMINI~1\\AppData\\Local\\Temp\\fnx_blender_export\\2020_10_30_09_11_27\\thumbnails\\FNX_CAMERA__test.png",
          "fov": 0.6911112070083618,
          "camera_transform": {
            "matrix": [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0]
          }
        }

    Args:
        output_dir: the output directory for the export

    Returns:
        custom camera dictionary

    """

    # Make thumbnails directory
    thumbnails_dir = output_dir / constants.FNX_MODO__THUMBNAILS_DIR_NAME
    thumbnails_dir.mkdir(exist_ok=True)

    # TODO: Right now we should only have one camera

    scene = modo.Scene()

    camera = scene.renderCamera

    if not camera:
        raise pl_exceptions.FNXException("No render camera.")

    thumbnail_base_path = str(thumbnails_dir / camera.name)

    CHANNEL_EDITS = {
        "resX": constants.FNX_MODO__THUMBNAIL_WIDTH,
        "resY": constants.FNX_MODO__THUMBNAIL_WIDTH,
        "directSmps": 16,
        "globRays": 16,
        "irrRays": 16,
        "outPat": "_"
    }

    with CustomRenderChannelContext(CHANNEL_EDITS.keys()):

        for channel_name, channel_value in CHANNEL_EDITS.items():
            modo.Scene().renderItem.channel(channel_name).set(channel_value)

        # The options are:
        #
        # 1: close window after render
        # 2: stats only
        # 4: Stop after IC pass
        #
        # 1+2+4 = 7: all the options are on
        # 1+2 = 3: close window after render, stats only
        # 2+4 = 6: Stop after IC pass, stats only
        #
        # Here's the actual flags, as defined in the internal code:
        #
        #     0x0001        NOT_WAITING        // Don't wait before rendering the next frame
        #     0x0002        NO_IMAGE            // Don't show the progress image
        #     0x0004        IC_ONLY            // Render IC only
        #     0x0008        NO_CLEANUP        // Don't clean up after rendering finishes
        #     0x1000        RENDER_ANIIM        // Set by render.animation to indicate that we're rendering an animation.
        #
        lx.eval("render filename:" + thumbnail_base_path + " format:PNG options:3")
        lx.eval("!render.clear")

    # res_x = float(scene.renderItem.channel('resX').get())
    # res_y = float(scene.renderItem.channel('resY').get())
    # aspect_ratio = (res_y / res_x)

    # Get the value of the focal length channel
    focal_length = camera.channel('focalLen').get()
    aperture_x = camera.channel('apertureX').get()

    horizontal_fov = math.degrees(2.0 * math.atan(aperture_x / (2.0 * focal_length)))
    # vFOV = horizontal_fov * aspect_ratio

    # Read the value of the world matrix channel
    world_matrix = modo.mathutils.Matrix4(camera.channel('worldMatrix').get())
    rotation = modo.mathutils.Quaternion()
    rotation.fromMatrix4(world_matrix)

    camera_dict = {
        "name": camera.name,
        "image_path": thumbnail_base_path + ".png",
        "fov": horizontal_fov,
        "camera_transform": {
            "position": world_matrix.position,
            "rotation": list(rotation.values)  # as a quaternion
        }
    }

    cameras = [camera_dict]

    return cameras


def run_checks():

    pl_utils.find_submitter()

    # Check file has been saved
    if not modo.Scene().filename:
        raise pl_exceptions.FNXException("Scene has not been saved.")


def export_bundle(output_dir, export_geo_settings):
    """
    Export a Modo bundle for the render service.

    Args:
        export_geo_settings:
        output_dir:

    Returns:

    """

    # Render camera views and collect cameras' data
    LOGGER.info("Rendering custom camera thumbnails...")

    custom_cameras = render_camera_views(output_dir=output_dir)

    # Generate config

    scene_data = {
        "garment_name": constants.FNX_MODO__GARMENT_COLLECTION_NAME,
        "num_colorways": 1,
        "serialized_colorways": [],
        "avatar_name": constants.FNX_MODO__AVATAR_COLLECTION_NAME,  # TODO: Handle multiple avatars
    }

    modo_version = lx.eval('query platformservice appversion ?')

    dcc_dict = {
        "name": constants.FNX_MODO__DCC_NAME,
        "version": modo_version
    }

    project_path = Path(modo.Scene().filename)
    project_name = project_path.stem

    fnxc_config_file = pl_utils.export_submit_config(
        output_dir,
        project_path,
        project_name,
        custom_cameras,
        dcc_dict,
        scene_data,
        geo_export=export_geo_settings
    )

    return fnxc_config_file


class FNXRenderCommand_Cmd(lxu.command.BasicCommand):

    def __init__(self):
        lxu.command.BasicCommand.__init__(self)

        self.scrp_svc = lx.service.ScriptSys()
        self._fbx_settings = {}

    def cmd_Flags(self):
        return lx.symbol.fCMD_UNDO | lx.symbol.fCMD_MODEL

    def get_user_value(self, name):
        try:
            value_obj = self.scrp_svc.UserValueLookup(name)
        except:
            return None

        itype = value_obj.Type()
        if itype == lx.symbol.i_TYPE_INTEGER:
            return value_obj.GetInt()

        if itype == lx.symbol.i_TYPE_STRING:
            return value_obj.GetString()

        if itype == lx.symbol.i_TYPE_FLOAT:
            return value_obj.GetFlt()

    def store_fbx_settings(self):
        self._fbx_settings = {}
        for x in range(self.scrp_svc.UserValueCount()):
            name = self.scrp_svc.UserValueByIndex(x).Name()
            if name.startswith(constants.FBX_USERVALUE_PREFIX):
                attr_name = name[len(constants.FBX_USERVALUE_PREFIX):]
                self._fbx_settings[attr_name] = self.get_user_value(name)

    def restore_fbx_settings(self):
        self.set_fbx_settings_from_dict(self._fbx_settings)

    def set_fbx_settings_from_dict(self, fbx_dict):
        for setting_name, setting_value in fbx_dict.items():
            lx.eval('user.value %s%s %s' % (constants.FBX_USERVALUE_PREFIX, setting_name, setting_value))

    def export_fbx(self, output_dir):
        export_settings = {
            'format': 0,  # Use latest
            'exportType': 0,  # export all
            'exportActionType': 0,
            'surfaceRefining': 1,
            'geometry': 1,
            'units': 0,
            'exportToASCII': 0,
            'animationOnly': 0,
            'cameras': 0,
            'lights': 0,
            'materials': 1,
            'polygonParts': 1,
            'selectionSets': 0,
            'smoothingGroups': 0,
            'morphMaps': 1,
            'tangentsBitangents': 1,
            'exportRgbaAsDiffCol': 0,
            'animation': 0,
            'sampleAnimation': 0,
            'scale': 1.0
        }

        self.set_fbx_settings_from_dict(export_settings)

        # Export the FBX.
        LOGGER.info("Exporting FBX...")
        fbx_export_dir = output_dir / "FBX_out"
        fbx_export_dir.mkdir(parents=True, exist_ok=True)

        project_path = Path(modo.Scene().filename)
        project_name = project_path.stem

        fbx_export_path = fbx_export_dir / (project_name + ".fbx")

        lx.eval('!scene.saveAs "%s" fbx true' % fbx_export_path)

        modo_images_dir = project_path.parent / "imported_images"

        # TODO: Do we need to consolidate the scene here and if we do, we need to revert back to previous file
        # TODO: Should we only do this if there is no imported_images folder?
        if not modo_images_dir.exists():
            raise pl_exceptions.FNXException("Modo scene has not been consolidated.")

        # Copy imported_images folder to the FBX_out directory
        fbx_images_dir = fbx_export_dir / "imported_images"
        shutil.copytree(str(modo_images_dir), str(fbx_images_dir))

        return export_settings

    def flatten_images(self):
        """
        Flatten multiple texture layer images into a single image.
        Modo supports multiple texture layers using the same effect but these are not handled by the FBX export.
        """

        scene_service = lx.service.Scene()
        current_scene = lxu.select.SceneSelection().current()

        def get_children(parent_item):
            """Gets all children of an item."""
            return [parent_item.SubByIndex(x) for x in range(parent_item.SubCount())]

        def get_root_items():
            """Gets items in the root of the shader tree."""
            # Get the render item type
            render_item_type = scene_service.ItemTypeLookup(lx.symbol.sITYPE_POLYRENDER)
            # There is only ever one render item in the scene so we can get any item of that type
            root_items = []
            render_item = current_scene.AnyItemOfType(render_item_type)
            if render_item.test():
                root_items = get_children(render_item)

            return root_items

        lxu.select.ItemSelection().clear()

        # Get a channel object
        chan = current_scene.Channels(lx.symbol.s_ACTIONLAYER_EDIT, 0.0)

        mask_type = scene_service.ItemTypeLookup(lx.symbol.sITYPE_MASK)
        image_map_type = scene_service.ItemTypeLookup(lx.symbol.sITYPE_IMAGEMAP)

        for root_item in get_root_items():
            # Only interested in mask type items
            if not root_item.TestType(mask_type):
                continue

            children = get_children(root_item)

            if len(children) < 2:
                continue

            effect_mapping = {}
            for child in children:
                if child.TestType(image_map_type):
                    try:
                        idx = child.ChannelLookup("effect")
                        if idx:
                            effect_type = chan.String(child, idx)
                            effect_mapping.setdefault(effect_type, []).append(child)
                    except LookupError:
                        pass

            # If we have multiple imageMap channels to the same effect, we need to flatten
            for effect_type, items in effect_mapping.items():
                if len(items) > 1:
                    # If we have multiple channels but all others are disabled, then we can just remove them
                    # and then check for Combining
                    enabled_items = []
                    for item in items:
                        try:
                            idx = item.ChannelLookup("enable")
                            is_enabled = chan.Integer(item, idx)
                        except LookupError:
                            continue

                        if not is_enabled:
                            # Remove it
                            lxu.select.ItemSelection().clear()
                            lx.eval('select.item {%s} add' % item.Ident())
                            lx.eval('texture.delete')
                            lxu.select.ItemSelection().clear()
                        else:
                            enabled_items.append(item)

                    if len(enabled_items) > 1:
                        lxu.select.ItemSelection().clear()
                        for eitem in enabled_items:
                            lxu.select.ItemSelection().select(eitem.Ident())
                            lx.eval('select.item {%s} add' % eitem.Ident())

                        lx.eval("image.flatten")

                        # Delete the now disabled other items
                        lxu.select.ItemSelection().clear()
                        for delete_item in enabled_items[:-1]:
                            lx.eval('select.item {%s} add' % delete_item.Ident())
                            lx.eval('texture.delete')

    def basic_Execute(self, _msg, _flags):

        # Check if scene is saved as we'll need to revert after export
        changed = lx.eval("query sceneservice scene.changed ? current")
        if changed:
            modo.dialogs.alert("!!!Scene not saved", "Please save so revert can be done after export", dtype="error")
            return False

        # Check for garment and invalid characters
        try:
            run_checks()
        except pl_exceptions.FNXExceptions as ex:
            LOGGER.error(ex)
            modo.dialogs.alert("Error running checks", str(ex), dtype="error")
            return False

        output_dir = pl_utils.create_output_temp_dir(constants.FNX_MODO__TMP_EXPORT_DIR_NAME)

        # Export geometry and textures
        try:
            self.flatten_images()
            # Store user's FBX preferences for restoring later.
            self.store_fbx_settings()
            export_geo_settings = self.export_fbx(output_dir)
        except pl_exceptions.FNXException as export_error:
            LOGGER.error(export_error)
            modo.dialogs.alert("Error running FBX export", str(export_error), dtype="error")
            return False
        finally:
            # Restore the FBX preferences.
            self.restore_fbx_settings()
            # Revert scene to undo the flatten images functionality
            lx.eval('!scene.revert')

        fnxc_config = export_bundle(
            output_dir,
            export_geo_settings
        )

        if not fnxc_config:
            # Cleanup
            shutil.rmtree(output_dir)
            raise pl_exceptions.NoConfigException()

        try:
            pl_utils.run_submitter(asset_path=fnxc_config, dry_run=False)
        except Exception as ex:
            shutil.rmtree(output_dir.as_posix())
            raise pl_exceptions.SubmitException(ex)


lx.bless(FNXRenderCommand_Cmd, "fnx.render")
