#
# FNX constants
#

FNX_SUBMITTER_APP_ENV_VAR = "FNX_SUBMITTER_APP"
FNX_CONFIG_FILE = "fnx.config"
FNX_CONFIG_FILE = "fnx.config"
FNX_SUBMISSION_TYPE_BLENDER = "blender_render_submission"
FNX_SUBMISSION_TYPE_BUNDLE = "bundle_render_submission"
FNX_SUBMISSION_TYPE_VRAY = "vray_render_submission"
