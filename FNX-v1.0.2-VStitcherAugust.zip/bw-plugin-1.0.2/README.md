# FNX Browzwear Plugin FNX v1.0.2

## Requirements
The environment variable `FNX_SUBMITTER_APP` must be set pointing to the FNX Submitter application, version 0.11.0 or higher.

--- 

## Usage

![alt text](resources/plugin_menu.png)

#### Submit to FNX
Export garment geometry and materials, and launch the FNX Submitter tool to submit for rendering.

Upon clicking this menu item, the following is expected:
- Garment is exported as an FBX, along with materials, to a temporary directory
- A FNX config file is generated in the directory
- The FNX Connect is launched with the bundled data


#### Reload Plugin
If you make any changes to the installed plugin (see below for installation instructions), 
you'll need to reload it by clicking this menu item.

---

## Installation
Clone this repository locally and copy the **FNX** directory in the 
following directory

- Windows:  %localappdata%\Browzwear\VStitcher\plugins
- Mac: ~/Library/Application Support/Browzwear/VStitcher/Plugins

from **VSticher** launch the **Preferences**

![alt text](resources/launch_preferences.png)

Navigate to the **Plugins** section. VStitcher should auto load the 
plugins but if it doesnt, use the refresh button on top-right corner.

![alt text](resources/load_plugin.png)

### Environment Variables
If the environment variable `FNX_SUBMITTER_APP` is not set on the user's system, VStitcher
will not be able to launch the FNX Submitter application.

![environment submitter warning](resources/env_var_msg_win.png)
