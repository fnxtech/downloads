import json
import shutil
import sys
import traceback

import BwApi

from logger import get_logger
from pathlib import Path
sys.path.insert(0, Path(__file__).absolute())
from export import export_bundle
from utils import (
    SUBMITTER_CHECK,
    GARMENT_CHECK,
    INVALID_CHARS_CHECK,
    do_checks,
    get_project_path,
    get_output_temp_dir,
    run_submitter,
    remove_temp_files
)


LOGGER = get_logger(__name__)


class Callback(BwApi.CallbackBase):
    SUBMIT_BUNDLE_AVATAR_ID = 1
    SUBMIT_BUNDLE_ALL_AVATAR_ID = 2

    def Run(self, garment_id, callback_id, data_string):
        try:
            if callback_id == Callback.SUBMIT_BUNDLE_AVATAR_ID:
                fnx_plugin.submit_bundle(include_avatar=True)

            if callback_id == Callback.SUBMIT_BUNDLE_ALL_AVATAR_ID:
                fnx_plugin.submit_bundle(all_colorways=True, include_avatar=True)

        except Exception as error:
            trace_back = traceback.format_exc()
            LOGGER.error(error)
            LOGGER.error(trace_back)
            BwApi.WndMessageBox("ERROR: {}".format(error), BwApi.BW_API_MB_OK)


class FNXPlugins:
    def __init__(self):
        self.garment_id = ''

    def submit_bundle(self, all_colorways=False, include_avatar=False):
        self.garment_id = BwApi.GarmentId()

        # Check for garment and invalid characters
        fail_code, fail_message = do_checks(self.garment_id)

        if fail_code in (SUBMITTER_CHECK, GARMENT_CHECK):
            LOGGER.error(fail_message)
            BwApi.WndMessageBox(fail_message, BwApi.BW_API_MB_OK)
            return False

        if all_colorways:
            colorway_ids = BwApi.GarmentColorwayIds(self.garment_id)
        else:
            colorway_ids = (BwApi.ColorwayCurrentGet(self.garment_id),)

        fnxc_config = None
        try:
            # Bundle up export assets
            output_dir = get_output_temp_dir()
            fnxc_config = export_bundle(self.garment_id, output_dir,
                                         colorway_ids=colorway_ids,
                                         include_avatar=include_avatar)
        except Exception as error:
            BwApi.WndMessageBox(str(error), BwApi.BW_API_MB_OK)
            fnxc_config = None

        # Launch FNX Connect
        if not fnxc_config:
            BwApi.WndMessageBox("Could not do exports.", BwApi.BW_API_MB_OK)
            shutil.rmtree(output_dir)
            return
        try:
            run_submitter(asset_path=fnxc_config, dry_run=False)
        except Exception as error:
            BwApi.WndMessageBox(str(error), BwApi.BW_API_MB_OK)
            shutil.rmtree(output_dir)

class EventCallback(BwApi.CallbackBase):
    POST_INTIALIZE_ID = 1
    def Run(self, garment_id, callback_id, data_string):
        if callback_id == EventCallback.POST_INTIALIZE_ID:
            # Remove temp bundles that are older than 1 week
            removed_bundles = remove_temp_files(days_delta=7)
            if removed_bundles:
                print("FNX::Removed temporary files older than 7 days:")
                print(removed_bundles)

        return 1


def BwApiPluginInit():
    BwApi.IdentifierSet(pluginIdentifier)
    BwApi.EventRegister(event_callback, event_callback.POST_INTIALIZE_ID, BwApi.BW_API_EVENT_POST_INTIALIZE)
    BwApi.MenuFunctionAdd('Submit Current Colorway to FNX', callback, callback.SUBMIT_BUNDLE_AVATAR_ID)
    BwApi.MenuFunctionAdd('Submit All Colorways to FNX', callback, callback.SUBMIT_BUNDLE_ALL_AVATAR_ID)
    BwApi.MenuFunctionReloadAdd()
    return int(0x000e0010)


pluginIdentifier = 'com.browzwear.fnx'
callback = Callback()
event_callback = EventCallback()
fnx_plugin = FNXPlugins()
