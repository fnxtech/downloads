# Python
import json
import random
import re
import string
import time
import unicodedata
import functools
from datetime import datetime
from pathlib import Path

# plugin-libs
from .plugin_libs.exceptions import FNXException
from .plugin_libs import utils as pl_utils

import BwApi


INVCHARS_PATTERN = re.compile(r"""[~`!@#$%\^\&\*()+=\\|;<>",?\/'\. {}:-]""",
                              re.IGNORECASE)

def fnx_handle_error(function):
    """A decorator that wraps the passed in function and 
    and raises a FNXException if there was an BwApi error.
    """
    error_codes = {
         0: 'BW_API_ERROR_SUCCESS',
        -1: 'BW_API_ERROR_UNDEFINED',
        -2: 'BW_API_ERROR_INTERNAL_ERROR',
        -3: 'BW_API_ERROR_PARAMS_INVALID',
        -4: 'BW_API_ERROR_INVALID_GARMENT',
        -5: 'BW_API_ERROR_GARMENT_ID_MISMATCH',
        -6: 'BW_API_ERROR_GARMENT_SIZE',
        -7: 'BW_API_ERROR_OBJECT_CREATION_FAILED',
        -8: 'BW_API_ERROR_OBJECT_DELETION_FAILED',
        -9: 'BW_API_ERROR_EDGE_POINTS_METHOD',
        -10: 'BW_API_ERROR_PARAMETER_NOT_FOUND',
        -11: 'BW_API_ERROR_SIZE_MISMATCH',
        -12: 'BW_API_ERROR_SYMMETRY',
        -13: 'BW_API_ERROR_RENAMING_FAILED',
        -14: 'BW_API_ERROR_POINT_CREATION_FAILED',
        -15: 'BW_API_ERROR_USER_DATA_KEY_INVALID',
        -16: 'BW_API_ERROR_OBJECT_NOT_FOUND',
        -17: 'BW_API_ERROR_WRONG_POINT_TYPE',
        -18: 'BW_API_ERROR_INVALID_CONTEXT',
        -19: 'BW_API_ERROR_SHAPE_INCOMPLETE',
        -20: 'BW_API_ERROR_INVALID_IDENTIFIER',
        -21: 'BW_API_ERROR_DEPRECATED_FUNCTION',
        -22: 'BW_API_ERROR_SET_MATERIAL_WRONG_TYPE',
        -23: 'BW_API_ERROR_LICENSE_INSUFFICIENT',
        -24: 'BW_API_ERROR_MATERIAL_TYPE_IS_GROUP_MATERIAL',
        -25: 'BW_API_ERROR_USER_ACTION_ONLY',
        -26: 'BW_API_ERROR_NO_SNAPSHOT_AVAILABLE',
        -27: 'BW_API_ERROR_API_NOT_SUPPORTED'
    }

    @functools.wraps(function)
    def wrapper(*args, **kwargs):
        ret_val = function(*args, **kwargs)
        last_error = BwApi.GetLastError()
        if last_error == BwApi.BW_API_ERROR_SUCCESS:
            return ret_val
        
        error = error_codes.get(last_error, 'error undefined')
        message = error.strip('BW_API_').replace('_', ' ').lower()

        if last_error == BwApi.BW_API_ERROR_NO_SNAPSHOT_AVAILABLE:
            message = "No snapshot is loaded. The avatar should be dressed first."

        raise FNXException(message)

    return wrapper


def get_dcc_version() -> dict:
    """The DCC's version is not exposed in the API. This parses
    the API source file's path and returns the DCC code name and 
    the DCC's edition appended with the API's version (if available).

    Examples of the API source file are
        C:\\Program Files\\Browzwear\\VStitcher\\2020 May Edition\\BwApi.py
        /Applications/Browzwear/VStitcher 2020 September Edition.app/Contents/MacOS/BwApi.py
        /Applications/Browzwear/Lotta 2020 September Edition.app/Contents/MacOS/BwApi.py

    Returns:
        (str, str): Code name of DCC, Full name of the DCC edition + API version

    Examples:
        ('BWV', '2020 May Edition, API version unknown')
        ('BWV', '2020 September Edition, API version 3.0')
        ('BWL', '2020 September Edition, API version 3.4')
    """
    try:
        api_version = BwApi.Version()[0]
    except AttributeError:
        api_version = "unknown"

    regex = r"(VStitcher|Lotta).(\d{4} \w+ Edition)"
    match = re.search(regex, BwApi.__file__)
    if not match:
        return "BWV", f"unknown edition, API version {api_version}"
    
    dcc, edition = match.groups()
    version = f"{edition}, API version {api_version}"
    code_name = "BWL" if dcc == "Lotta" else "BWV"

    # Return as dictionary
    return {"name": code_name, "version": version}


def get_avatar_name() -> str:
    """Get the avatar name that is consistent with 
    the avatar geometry in Blender FBX imports."""
    avatar = BwApi.AvatarCurrentGet()
    avatar_name = json.loads(BwApi.AvatarPropertiesGet()).get('name')
    prefix_length = len(avatar_name) + 1 # Account for appended underscore
    base_name = avatar[prefix_length:]
    return base_name


# \todo: We need to come up with a more unified way to sanitize string data.
def remove_control_characters(string: str) -> str:
    """Remove only control characters from the given string."""
    return "".join(ch for ch in string if unicodedata.category(ch)[0] != "C")


def sanitize_name(word: str) -> str:
    """Remove the illegal/invalid character from the given name and return
    encoded strings.
    .. code-block:: python
       >>> print sanitize_name("some pt^&%###% !@#$%^- .21358 Else and _Mor")
       ... "somept21358Elseand_Mor"
       >>> print sanitize_name("╡╡╖╣└╠┐°╗τf_COL_R255_G255_B255_DESATURATION")
       ... "UUUUUUUUUUf_COL_R255_G255_B255_DESATURATION"
       >>> print sanitize_name(r'┐⌐└┌ TEE,PT@3x_4cm')
       ... "NNNNTEEPT3x_4cm"
    :type word: str
    :param word: string to be sanitized
    :rtype: str
    :return: sanitized name
    """
    if not all(ord(_) < 128 for _ in word):
        # removing any possible ascii character
        word = word.encode("ascii", "replace").decode("utf-8")

        # since the above code will replace any invalid character with "?" we
        # are going to replace them with a random character
        word = word.replace("?", random.choice(string.ascii_uppercase))

    # replace unwanted characters
    word = INVCHARS_PATTERN.sub('', word)
    word = word.strip()

    return word


@fnx_handle_error
def render_camera_views(out_path: Path, garment_id: str, camera_views: list, width: int, height: int, include_avatar=False):
    captures = []

    # Get camera data for each of the camera views in the scene.
    for index, camera_view in enumerate(camera_views):
        cam_data_str = BwApi.EnvironmentCameraViewGet(garment_id, camera_view)
        camera_data = json.loads(cam_data_str)
        # Note: VStitcher's render.json schema and camera.json schema do not validate 
        #       against properties "camera_name", and "width" and "height", respectively.
        #       Therefore, let's add these values in the render params so we could
        #       use them in writing to the FNX Connect config file.
        camera_name = camera_views[index]
        capture = {
            "camera": camera_data,
            "path": str(out_path / f"{camera_name}.png"),
            "camera_name": camera_name
        }
        captures.append(capture)

    render_params = {
        "render": {
            "normal": {
                "outline": False,
                "background": "transparent"
            }
        },
        "include_avatar": include_avatar,
        "width": width,
        "height": height,
        "captures": captures
    }

    BwApi.RenderImage(garment_id, json.dumps(render_params))

    return render_params


def get_snapshot_date(garment_id, snapshot_id) -> "datetime.datetime":
    """Get the snapshot's creation date.

    Args:
        garment_id: Garment ID
        snapshot_id: Snapshot ID

    Returns:
        datetime.datetime: Date object
    """
    snapshot_info = get_snapshot_info(garment_id, snapshot_id)
    # Workaround to python 3.7 bug: https://bugs.python.org/issue27400
    snapshot_date = snapshot_info["created_date"]
    try:
        snapshot_date = datetime.strptime(snapshot_date, "%Y-%m-%dT%X")
    except TypeError:
        mktime = time.strptime(snapshot_date, "%Y-%m-%dT%X")
        snapshot_date = datetime.fromtimestamp(time.mktime(mktime))

    return snapshot_date


def get_latest_snapshot_id(garment_id: str=None) -> str:
    """Get the ID of the latest snapshot, based on "created_date" value.

    Args:
        garment_id: Garment ID

    Returns:
        str: Snapshot ID
    """
    garment_id = garment_id or BwApi.GarmentId()
    snapshot_ids = list(BwApi.GarmentSnapshotIds(garment_id))
    snapshot_ids.sort(key=lambda sid: get_snapshot_date(garment_id, sid), reverse=True)

    return snapshot_ids[0] if snapshot_ids else ""


def get_snapshot_info(garment_id: str, snapshot_id: str) -> dict:
    """Get the given snapshot's information.

    Args:
        garment_id: Garment ID
        snapshot_id: Snapshot ID

    Returns:
        dict: Snapshot's info.
    """
    if snapshot_id not in BwApi.GarmentSnapshotIds(garment_id):
        raise FNXException(f"Snapshot '{snapshot_id}' does not exist in garment {garment_id}")

    ss_info_string = BwApi.SnapshotInfoGet(garment_id, snapshot_id)
    ss_info = json.loads(ss_info_string)

    return ss_info


def get_project_path(garment_id=None) -> Path:
    """Gets the garment's project file path.

    Args:
        garment_id (`str`): Garment ID. Defaults to None.

    Returns:
        `Path`: File path of the current project.
    """
    garment_id = garment_id or BwApi.GarmentId()
    garment_path = Path(BwApi.GarmentPathGet(garment_id))

    # prior to version 2020.50591 the project path was pointing to sqlite, but
    # since this version it is actually pointing to .bw file path. so this check
    # would make sure this plugin is backward compatible
    if garment_path.name == '__bwsqlitefoler__':
        garment_path = garment_path.parent

    return garment_path


def do_checks(garment_id):

    # Check if FNX Connect is running
    connect_status = pl_utils.get_connect_status()
    if connect_status.error:
        msg = (f"{connect_status.message}.\n"
               f"Make sure it's running in the background and try again.")
        raise FNXException(msg)

    if not garment_id:
        raise FNXException("No garment found.")

    # Check if project file is a .bw file
    garment_path = get_project_path(garment_id)
    if not garment_path.suffix == '.bw':
        message = "Project file not supported.\n\nSave project as .bw file before submitting garment to FNX."
        raise FNXException(message)


def is_alvanon_avatar() -> bool:
    """Check if the current avatar is Alvanon.

    Returns:
        bool: True if the avatar in the scene is an Alvanon avatar.
    """
    # TODO: This is a bit of a crude way to identify the Alvanon avatar
    return BwApi.AvatarPoseCurrentGet().startswith('Take')


if __name__ == '__main__':
    print(__doc__)
