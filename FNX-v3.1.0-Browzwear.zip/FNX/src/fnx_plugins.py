# Python
import os
from pathlib import Path
import shutil
import traceback
import time

# Browzwear
import BwApi

# plugin-libs
from src.plugin_libs import constants as pl_constants
from src.plugin_libs import exceptions as pl_exceptions
from src.plugin_libs import utils as pl_utils
from src.plugin_libs.logger import get_logger

# FNX
from src import constants
from src.export import export_bundle, export_vrscene
from src.utils import do_checks, get_latest_snapshot_id


LOGGER = get_logger(__name__)


class Callback(BwApi.CallbackBase):
    SUBMIT_BUNDLE_AVATAR_ID = 1
    SUBMIT_BUNDLE_ALL_AVATAR_ID = 2
    SUBMIT_BATCH_CBID = 3
    SUBMIT_VRAY = 4
    batch_event_callback = None

    def Run(self, _garment_id, callback_id, _data_string):
        session_id = str(time.time())
        try:
            if callback_id == Callback.SUBMIT_BUNDLE_AVATAR_ID:
                fnx_plugin.submit_bundle(session_id, include_avatar=True)

            if callback_id == Callback.SUBMIT_BUNDLE_ALL_AVATAR_ID:
                fnx_plugin.submit_bundle(session_id, all_colorways=True, include_avatar=True)

            if callback_id == Callback.SUBMIT_BATCH_CBID:
                # Get .bw scene paths in selected directory
                folder_path = Path(BwApi.WndFileDialog(1, 1, '', '', '', ''))
                scene_paths = list(folder_path.glob("*.bw"))
                if not scene_paths:
                    BwApi.WndMessageBox(f"No .bw files found in '{folder_path}'", BwApi.BW_API_MB_OK)
                    return
                # Set up event callback that gets triggered when the garment's snapshot is finished loading
                Callback.batch_event_callback = BatchSubmitEventCallback(session_id, scene_paths)
                func_id = BwApi.EventRegister(Callback.batch_event_callback, -1, BwApi.BW_API_EVENT_GARMENT_SIMULATION_FINISHED)
                Callback.batch_event_callback.func_id = func_id
                # Close current scene, open the first scene, and load snapshot
                BwApi.GarmentClose(BwApi.GarmentId(), discardChanges=True)
                BwApi.GarmentOpen(str(scene_paths[0]))
                garment_id = BwApi.GarmentId()
                snapshot_id = get_latest_snapshot_id(garment_id)
                BwApi.SnapshotLoad(garment_id, snapshot_id)

            if callback_id == Callback.SUBMIT_VRAY:
                fnx_plugin.submit_vray()

        except Exception as error:
            trace_back = traceback.format_exc()
            LOGGER.error(error)
            LOGGER.error(trace_back)
            BwApi.WndMessageBox("ERROR: {}".format(error), BwApi.BW_API_MB_OK)


class FNXPlugins:
    def __init__(self):
        self.garment_id = ''

    def submit_bundle(self, session, is_batch=False, all_colorways=False, include_avatar=False):
        self.garment_id = BwApi.GarmentId()

        # Check for garment and invalid characters
        try:
            do_checks(self.garment_id)
        except pl_exceptions.FNXExceptions as ex:
            LOGGER.error(ex)
            BwApi.WndMessageBox(str(ex), BwApi.BW_API_MB_OK)
            return False

        if all_colorways:
            colorway_ids = BwApi.GarmentColorwayIds(self.garment_id)
        else:
            colorway_ids = (BwApi.ColorwayCurrentGet(self.garment_id),)

        output_dir = pl_utils.create_output_temp_dir(constants.FNX_BWV__TMP_EXPORT_DIR_NAME)
        try:
            # Bundle up export assets
            fnxc_config = export_bundle(
                self.garment_id,
                output_dir,
                colorway_ids=colorway_ids,
                include_avatar=include_avatar
            )
        except pl_exceptions.FNXExceptions as ex:
            BwApi.WndMessageBox(str(ex), BwApi.BW_API_MB_OK)
            fnxc_config = None

        # Launch FNX Connect
        if not fnxc_config:
            BwApi.WndMessageBox("Could not do exports.", BwApi.BW_API_MB_OK)
            shutil.rmtree(output_dir)
            return

        try:
            pl_utils.run_submitter_http(asset_path=fnxc_config, session_id=session, is_batch=is_batch)
        except Exception as error:
            BwApi.WndMessageBox(str(error), BwApi.BW_API_MB_OK)
            shutil.rmtree(output_dir)

    def submit_vray(self):
        """Export a simple vrscene file for rendering on FNX platform."""
        session_id = str(time.time())
        output_dir = pl_utils.create_output_temp_dir(
            constants.FNX_BWV__TMP_EXPORT_DIR_NAME,
            name=f"vray_{session_id}")
        export_settings = export_vrscene(BwApi.GarmentId(), output_dir)
        vrscene_file_path = Path(export_settings["path"])

        try:
            pl_utils.run_submitter_http(
                session_id=session_id,
                asset_path=vrscene_file_path,
                action_type=pl_constants.FNX_SUBMISSION_TYPE_VRAY
            )
        except Exception as error:
            BwApi.WndMessageBox(str(error), BwApi.BW_API_MB_OK)
            shutil.rmtree(output_dir)


class BatchSubmitEventCallback(BwApi.CallbackBase):
    def __init__(self, session_id, scene_paths):
        super().__init__()
        self.session_id = session_id
        self.scene_paths = scene_paths
        self.func_id = None

    def Run(self, garment_id, callback_id, data_string):
        fnx_plugin.submit_bundle(self.session_id, is_batch=True, all_colorways=True, include_avatar=True)
        # Remove first scene in the batch because it
        # is already opened and loaded at this point
        self.scene_paths.pop(0)
        if not self.scene_paths:
            BwApi.EventUnregister(self.func_id)
            return

        BwApi.GarmentClose(garment_id, discardChanges=True)
        BwApi.GarmentOpen(str(self.scene_paths[0]))
        garment_id = BwApi.GarmentId()
        snapshot_id = get_latest_snapshot_id(garment_id)
        # SnapshotLoad triggers a call to Run() again through BW's callback system
        BwApi.SnapshotLoad(garment_id, snapshot_id)


class EventCallback(BwApi.CallbackBase):
    POST_INTIALIZE_ID = 1
    def Run(self, _garment_id, callback_id, _data_string):
        if callback_id == EventCallback.POST_INTIALIZE_ID:
            # Remove temp bundles that are older than 1 week
            removed_bundles = pl_utils.remove_temp_files(constants.FNX_BWV__TMP_EXPORT_DIR_NAME, days_delta=7)
            if removed_bundles:
                LOGGER.info("FNX::Removed temporary files older than 7 days:")
                LOGGER.info(removed_bundles)

        return 1


def BwApiPluginInit():
    BwApi.IdentifierSet(pluginIdentifier)
    BwApi.EventRegister(event_callback, event_callback.POST_INTIALIZE_ID, BwApi.BW_API_EVENT_POST_INTIALIZE)
    BwApi.MenuFunctionAdd('Submit Current Colorway to FNX', callback, callback.SUBMIT_BUNDLE_AVATAR_ID)
    BwApi.MenuFunctionAdd('Submit All Colorways to FNX', callback, callback.SUBMIT_BUNDLE_ALL_AVATAR_ID)
    if os.environ.get('FNX_BATCH_SUBMIT'):
        BwApi.MenuFunctionAdd('Batch Submit Scenes to FNX', callback, callback.SUBMIT_BATCH_CBID)
    BwApi.MenuFunctionAdd('Submit VRay Job to FNX', callback, callback.SUBMIT_VRAY)
    BwApi.MenuFunctionReloadAdd()
    return int(0x000e0010)


pluginIdentifier = 'com.browzwear.fnx'
callback = Callback()
event_callback = EventCallback()
fnx_plugin = FNXPlugins()
