"""FNX Blender plugin exceptions."""


class FNXException(Exception):
    """FNX base exception."""


class SubmitterDoesNotExistException(FNXException):
    """Submitter does not exist exception."""

    _MESSAGE = (
        "FNX Submitter v0.12.0 (or higher) was not found on your system. "
        "Please ask your system administrator to set "
        "the environment variable 'FNX_SUBMITTER_APP' to the FNX "
        "Submitter executable path.\nSaving your work and "
        "restarting Blender is required."
    )

    def __str__(self):
        return SubmitterDoesNotExistException._MESSAGE


class SubmitterExeDoesNotExistException(FNXException):
    """Submitter does not exist exception."""

    _MESSAGE = (
        "Environment variable 'FNX_SUBMITTER_APP' is set to '%s' "
        "but this path does not exist on your system. Please ask "
        "your system administrator to correctly set "
        "the executable's path.\nSaving your work and "
        "restarting Blender is required."
    )

    def __init__(self, submitter_exe_path):
        super(SubmitterExeDoesNotExistException, self).__init__()
        self._message = SubmitterExeDoesNotExistException._MESSAGE % submitter_exe_path

    def __str__(self):
        return self._message


class NoConfigException(Exception):
    """No config exception."""

    _MESSAGE = "No config.  Cannot submit job."

    def __str__(self):
        return NoConfigException._MESSAGE


class SubmitException(Exception):
    """Submit error exception."""

    _MESSAGE = "Error running submitter: "

    def __init__(self, exception):
        super(SubmitException, self).__init__()
        self._message = SubmitException._MESSAGE + str(exception)

    def __str__(self):
        return self._message


FNXExceptions = (
    FNXException,
    SubmitterDoesNotExistException,
    SubmitterExeDoesNotExistException,
    NoConfigException,
    SubmitException,
)
