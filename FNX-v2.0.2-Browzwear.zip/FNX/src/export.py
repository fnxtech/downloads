# Python
import json
import sys
import tempfile
from logger import get_logger
from os import path, makedirs
from pathlib import Path
sys.path.insert(0, path.abspath(__file__))

# Browzwear
import BwApi

# FNX
from utils import (
    current_time,
    get_avatar_name,
    get_dcc_version,
    fnx_handle_error,
    render_camera_views,
    is_alvanon_avatar,
    FnxException
)

LOGGER = get_logger(__name__)

FNX_CONFIG_FILE = "fnx.config"


def export_succeed():
    last_error = BwApi.GetLastError()
    print("ERROR: Exporting failed -- {}".format(last_error))
    if last_error != BwApi.BW_API_ERROR_SUCCESS:
        if last_error == BwApi.BW_API_ERROR_NO_SNAPSHOT_AVAILABLE:
            BwApi.WndMessageBox("No snapshot is loaded. The avatar should be dressed first.", BwApi.BW_API_MB_OK)

        return False

    return True


def get_colorway_names(garment_id, current_colorway=False):
    """
    Get all colorway names for the given garment.

    :param garment_id: id of the current garment
    :type garment_id: int
    :param current_colorway: Whether to get only the current colorway or all colorways.
    :type current_colorway: bool
    :rtype: generator object
    :return: Generator yielding colorway names
    """
    if current_colorway:
        colorway_ids = [BwApi.ColorwayCurrentGet(garment_id)]
    else:
        colorway_ids = list(BwApi.GarmentColorwayIds(garment_id))

    for cid in colorway_ids:
        yield BwApi.ColorwayNameGet(garment_id, cid)


@fnx_handle_error
def export_fbx(garment_id: str, output_dir: Path, colorway_ids=(), include_avatar=True, binary=True) -> dict:
    """
    Export garment geometry as FBX in a temp location

    :param garment_id: id of the current garment
    :type garment_id: int
    :rtype: str
    :return: path to the exported FBX file
    """
    project_name = BwApi.GarmentNameGet(garment_id)
    fbx_file_path = output_dir / f"{project_name}.fbx"
    export_settings = {
        "3d_format": "browzwear_pbr_fbx",
        "version": "FBX201800",
        "type": "binary" if binary else "ascii",
        "path": str(fbx_file_path),
        "up_axis": "y",
        "scale": 1,
        "use_pattern_pieces_names": True,
        "layout": {
            "layout_type": "native_uv",
            "image": "combined_image",
            "dpi": 100,
            "use_material_names": True,
            "embed_offset": True
        },
        "include_avatar": include_avatar
    }
    # If we're dealing with an Alvanon avatar, match garment to avatar
    if is_alvanon_avatar() and include_avatar:
        export_settings["match_garment"] = True

    if len(colorway_ids) > 1:
        multipack = []
        for colorway_id in colorway_ids:
            multipack.append({
                "colorway_id": int(colorway_id),
                "position": [0, 0, 0]
            })

        export_settings['layout']["multipack"] = multipack

    BwApi.RenderExport3DObject(garment_id, json.dumps(export_settings))

    return export_settings


@fnx_handle_error
def export_obj(garment_id, output_dir=None, include_avatar=True):
    """Export garment geometry as OBJ in a temp location

    :param garment_id: id of the current garment
    :type garment_id: int
    :param output_dir: Directory to save the obj file/textures
    :type output_dir: str
    :param include_avatar: Whether to export OBJ with avatar geometry included.
    :type include_avatar: bool
    :rtype: str
    :return: path to the exported OBJ file
    """
    if output_dir:
        temp_location = path.join(output_dir, 'OBJ_out')
    else:
        temp_location = path.join(tempfile.gettempdir(),
                                'fnx_export_obj',
                                current_time())

    if not path.exists(temp_location):
        makedirs(temp_location)

    obj_file_path = path.join(temp_location, '{}.obj'.format(current_time()))
    export_settings = {
        "3d_format": "obj",
        "path": obj_file_path,
        "up_axis": "y",
        "scale": 0.01,
        "use_pattern_pieces_names": True,
        "layout": {
            "layout_type": "layout_uv",
            "export_inside": True,
            "piece": "per_piece",
            "dpi": 100,  # between 50 - 400
            "embed_offset": True,
        },
        "include_avatar": include_avatar,
    }

    BwApi.RenderExport3DObject(garment_id, json.dumps(export_settings))

    return export_settings


def get_scene_data(garment_id, colorway_ids):

    serialized_colorways = []
    for colorway_id in colorway_ids:
        colorway_name = BwApi.ColorwayNameGet(garment_id, colorway_id)
        # sanitizing the name from any character that would cause issue in
        # file name
        colorway_name = colorway_name.replace('/', '')
        serialized_colorways.append(f"{colorway_id}_{colorway_name}")

    scene_data = {
        'garment_name': BwApi.GarmentNameGet(garment_id),
        'num_colorways': len(colorway_ids),
        'serialized_colorways': serialized_colorways,
        'colorway_id': BwApi.ColorwayCurrentGet(garment_id),
        'avatar_name': get_avatar_name(),
        'avatar_pose': BwApi.AvatarPoseCurrentGet(),
        'current_avatar': BwApi.AvatarCurrentGet()
    }

    return scene_data


def export_submit_config(garment_id: int, colorway_ids: list, export_geo_settings: dict, custom_cameras: list,
                         base_path: Path):
    """
    Export config to FNX config file.

    Args:
        garment_id (int): id of the current garment
        colorway_ids (list): list of colorway ids
        export_geo_settings (dict): export settings dictionary
        custom_cameras (list): list of custom cameras
        base_path (Path): the output directory base path

    Returns:
    """
    plugin_json = Path(__file__).parents[1] / "plugin.json"
    with open(plugin_json, 'r') as pjson:
        plugin_dict = json.load(pjson)

    project_name = BwApi.GarmentNameGet(garment_id)

    project_path = Path(BwApi.GarmentPathGet(garment_id))
    if project_path.name == "__bwsqlitefoler__":
        project_path = project_path.parent

    project_file = str(project_path).replace('\\', '/')

    dcc, dcc_version = get_dcc_version()

    # Write config file that drives FNX Connect
    fnxc_config = {
        "config_version": 2,
        "custom_cameras": custom_cameras,
        "data": str(base_path),
        "additional_files": {"beproduct_render_blender": [project_file]},
        "project_file": project_file,
        "project_name": project_name,
        "dcc": {
            "name": dcc,
            "version": dcc_version
        },
        "plugin": plugin_dict,
        "scene_data": get_scene_data(garment_id, colorway_ids),
        "geo_export": export_geo_settings
    }

    fnxc_config_file = base_path / FNX_CONFIG_FILE
    with open(fnxc_config_file, 'w') as file_handle:
        json.dump(fnxc_config, file_handle, indent=2)

    return fnxc_config_file


def export_bundle(garment_id: str, output_dir: Path, colorway_ids=None, include_avatar=False) -> Path:
    """Export the garment geo and textures for bw-to-blender render service."""

    # Render camera views and collect cameras' data
    LOGGER.info(' Rendering custom camera thumbnails '.center(80, "*"))
    custom_cameras = []
    all_cameras = set(BwApi.EnvironmentCameraViews())
    default_cameras = set(["Top", "Bottom", "Left", "Right", "Front", "Back"])
    camera_views = list(all_cameras.difference(default_cameras))
    if camera_views and not is_alvanon_avatar():
        thumbnails_dir = output_dir / "thumbnails"
        thumbnails_dir.mkdir(exist_ok=True)
        render_params = render_camera_views(out_path=thumbnails_dir,
                                            garment_id=garment_id,
                                            camera_views=camera_views,
                                            width=150,
                                            height=150,
                                            include_avatar=include_avatar)

        captures = render_params["captures"]
        for capture in captures:
            camera = dict()
            camera["name"] = capture["camera_name"]
            camera["image_path"] = capture["path"]
            camera_data = capture["camera"]
            camera["fov"] = camera_data.pop("fov")
            camera["camera_transform"] = camera_data
            custom_cameras.append(camera)

    # Export geometry and textures
    colorway_ids = colorway_ids or (BwApi.ColorwayCurrentGet(garment_id),)
    LOGGER.info(' Exporting FBX '.center(80, "*"))
    fbx_out_path = output_dir / "FBX_out"
    fbx_out_path.mkdir(parents=True, exist_ok=True)
    try:
        export_geo_settings = export_fbx(garment_id=garment_id,
                                         output_dir=fbx_out_path,
                                         colorway_ids=colorway_ids,
                                         include_avatar=include_avatar,
                                         binary=True)
    except FnxException as export_error:
        BwApi.WndMessageBox(str(export_error), BwApi.BW_API_MB_OK)
        return None

    fbx_path = Path(export_geo_settings['path'])
    assert fbx_path.exists(), "FBX geometry and textures failed to export."
    # Make FBX path relative.
    export_geo_settings['path'] = str(fbx_path.relative_to(output_dir))

    fnxc_config_file = export_submit_config(
        garment_id,
        colorway_ids,
        export_geo_settings,
        custom_cameras,
        output_dir
    )

    return fnxc_config_file
