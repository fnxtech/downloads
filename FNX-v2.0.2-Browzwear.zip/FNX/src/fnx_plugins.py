import json
import os
import shutil
import sys
import traceback
import time
import BwApi

from logger import get_logger
from pathlib import Path
sys.path.insert(0, Path(__file__).absolute())
from export import export_bundle
from utils import (
    SUBMITTER_CHECK,
    GARMENT_CHECK,
    do_checks,
    get_output_temp_dir,
    run_submitter,
    remove_temp_files,
    get_latest_snapshot_id
)


LOGGER = get_logger(__name__)


class Callback(BwApi.CallbackBase):
    SUBMIT_BUNDLE_AVATAR_ID = 1
    SUBMIT_BUNDLE_ALL_AVATAR_ID = 2
    SUBMIT_BATCH_CBID = 3
    batch_event_callback = None

    def Run(self, garment_id, callback_id, data_string):
        session_id = str(time.time())
        try:
            if callback_id == Callback.SUBMIT_BUNDLE_AVATAR_ID:
                fnx_plugin.submit_bundle(session_id, include_avatar=True)

            if callback_id == Callback.SUBMIT_BUNDLE_ALL_AVATAR_ID:
                fnx_plugin.submit_bundle(session_id, all_colorways=True, include_avatar=True)

            if callback_id == Callback.SUBMIT_BATCH_CBID:
                # Get .bw scene paths in selected directory
                folder_path = Path(BwApi.WndFileDialog(1, 1, '', '', '', ''))
                scene_paths = list(folder_path.glob("*.bw"))
                if not scene_paths:
                    BwApi.WndMessageBox(f"No .bw files found in '{folder_path}'", BwApi.BW_API_MB_OK)
                    return
                # Set up event callback that gets triggered when the garment's snapshot is finished loading
                Callback.batch_event_callback = BatchSubmitEventCallback(session_id, scene_paths)
                func_id = BwApi.EventRegister(Callback.batch_event_callback, -1, BwApi.BW_API_EVENT_GARMENT_SIMULATION_FINISHED)
                Callback.batch_event_callback.func_id = func_id
                # Close current scene, open the first scene, and load snapshot
                BwApi.GarmentClose(BwApi.GarmentId(), discardChanges=True)
                BwApi.GarmentOpen(str(scene_paths[0]))
                garment_id = BwApi.GarmentId()
                snapshot_id = get_latest_snapshot_id(garment_id)
                BwApi.SnapshotLoad(garment_id, snapshot_id)

        except Exception as error:
            trace_back = traceback.format_exc()
            LOGGER.error(error)
            LOGGER.error(trace_back)
            BwApi.WndMessageBox("ERROR: {}".format(error), BwApi.BW_API_MB_OK)


class FNXPlugins:
    def __init__(self):
        self.garment_id = ''

    def submit_bundle(self, session, is_batch=False, all_colorways=False, include_avatar=False):
        self.garment_id = BwApi.GarmentId()

        # Check for garment and invalid characters
        fail_code, fail_message = do_checks(self.garment_id)

        if fail_code in (SUBMITTER_CHECK, GARMENT_CHECK):
            LOGGER.error(fail_message)
            BwApi.WndMessageBox(fail_message, BwApi.BW_API_MB_OK)
            return False

        if all_colorways:
            colorway_ids = BwApi.GarmentColorwayIds(self.garment_id)
        else:
            colorway_ids = (BwApi.ColorwayCurrentGet(self.garment_id),)

        fnxc_config = None
        output_dir = get_output_temp_dir()
        output_dir.mkdir(exist_ok=True, parents=True)
        try:
            # Bundle up export assets
            fnxc_config = export_bundle(self.garment_id, output_dir,
                                         colorway_ids=colorway_ids,
                                         include_avatar=include_avatar)
        except Exception as error:
            BwApi.WndMessageBox(str(error), BwApi.BW_API_MB_OK)
            fnxc_config = None

        # Launch FNX Connect
        if not fnxc_config:
            BwApi.WndMessageBox("Could not do exports.", BwApi.BW_API_MB_OK)
            shutil.rmtree(output_dir)
            return
        try:
            run_submitter(session, asset_path=fnxc_config, is_batch=is_batch, dry_run=False)
        except Exception as error:
            BwApi.WndMessageBox(str(error), BwApi.BW_API_MB_OK)
            shutil.rmtree(output_dir)


class BatchSubmitEventCallback(BwApi.CallbackBase):
    def __init__(self, session_id, scene_paths):
        super().__init__()
        self.session_id = session_id
        self.scene_paths = scene_paths
        self.func_id = None

    def Run(self, garment_id, callback_id, data_string):
        fnx_plugin.submit_bundle(self.session_id, is_batch=True, all_colorways=True, include_avatar=True)
        # Remove first scene in the batch because it
        # is already opened and loaded at this point
        self.scene_paths.pop(0)
        if not self.scene_paths:
            BwApi.EventUnregister(self.func_id)
            return

        BwApi.GarmentClose(garment_id, discardChanges=True)
        BwApi.GarmentOpen(str(self.scene_paths[0]))
        garment_id = BwApi.GarmentId()
        snapshot_id = get_latest_snapshot_id(garment_id)
        # SnapshotLoad triggers a call to Run() again through BW's callback system
        BwApi.SnapshotLoad(garment_id, snapshot_id)


class EventCallback(BwApi.CallbackBase):
    POST_INTIALIZE_ID = 1
    def Run(self, garment_id, callback_id, data_string):
        if callback_id == EventCallback.POST_INTIALIZE_ID:
            # Remove temp bundles that are older than 1 week
            removed_bundles = remove_temp_files(days_delta=7)
            if removed_bundles:
                LOGGER.info("FNX::Removed temporary files older than 7 days:")
                LOGGER.info(removed_bundles)

        return 1


def BwApiPluginInit():
    BwApi.IdentifierSet(pluginIdentifier)
    BwApi.EventRegister(event_callback, event_callback.POST_INTIALIZE_ID, BwApi.BW_API_EVENT_POST_INTIALIZE)
    BwApi.MenuFunctionAdd('Submit Current Colorway to FNX', callback, callback.SUBMIT_BUNDLE_AVATAR_ID)
    BwApi.MenuFunctionAdd('Submit All Colorways to FNX', callback, callback.SUBMIT_BUNDLE_ALL_AVATAR_ID)
    if os.environ.get('FNX_BATCH_SUBMIT'):
        BwApi.MenuFunctionAdd('Batch Submit Scenes to FNX', callback, callback.SUBMIT_BATCH_CBID)
    BwApi.MenuFunctionReloadAdd()
    return int(0x000e0010)


pluginIdentifier = 'com.browzwear.fnx'
callback = Callback()
event_callback = EventCallback()
fnx_plugin = FNXPlugins()
