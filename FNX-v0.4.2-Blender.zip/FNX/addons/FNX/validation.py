# Blender
import bpy

# plugin-libs
from .plugin_libs import utils as pl_utils

# FNX
from . import constants
from . import utils


class FNXBaseValidator:

    name: str
    issue_type: str

    def validate(self):
        pass


class FNXGarmentCollectionValidator(FNXBaseValidator):

    name = f"No garment collection '{constants.FNX_BLENDER__GARMENT_COLLECTION_NAME}'"
    issue_type = constants.FNX_ERROR

    def validate(self):
        garment_collection = bpy.data.collections.get(
            constants.FNX_BLENDER__GARMENT_COLLECTION_NAME
        )
        if not garment_collection:
            return False

        return True

    def fix(self):
        collection = bpy.data.collections.new(constants.FNX_BLENDER__GARMENT_COLLECTION_NAME)
        bpy.context.scene.collection.children.link(collection)


class FNXGarmentObjectsValidator(FNXBaseValidator):

    name = "No garment items."
    issue_type = constants.FNX_ERROR

    def validate(self):
        garment_collection = bpy.data.collections.get(
            constants.FNX_BLENDER__GARMENT_COLLECTION_NAME
        )
        if garment_collection and not len(garment_collection.all_objects):
            return False

        return True


class FNXAvatarValidator(FNXBaseValidator):

    name = f"No avatar collection '{constants.FNX_BLENDER__AVATAR_COLLECTION_NAME}'"
    issue_type = constants.FNX_INFO

    def validate(self):
        garment_collection = bpy.data.collections.get(
            constants.FNX_BLENDER__AVATAR_COLLECTION_NAME
        )
        if not garment_collection:
            return False

        return True

    def fix(self):
        collection = bpy.data.collections.new(constants.FNX_BLENDER__AVATAR_COLLECTION_NAME)
        bpy.context.scene.collection.children.link(collection)


class FNXCamerasValidator(FNXBaseValidator):

    name = "No FNX cameras in scene"
    issue_type = constants.FNX_INFO

    def validate(self):

        # We should have at least one camera
        if not utils.get_fnx_scene_cameras():
            return False

        return True

    def fix(self):
        camera_name = constants.FNX_BLENDER__CAMERA_NAME_PREFIX + "test"
        scn = bpy.context.scene
        cam = bpy.data.cameras.new(camera_name)
        cam_obj = bpy.data.objects.new(camera_name, cam)
        cam_obj.location = (0, 0, 0)
        cam_obj.rotation_euler = (0, 0, 0)
        scn.collection.objects.link(cam_obj)


class FNXColorwayIndexValidator(FNXBaseValidator):
    """Validate that the colorway index exists on all objects in the garment group."""

    name = "Incompatible colorway indices"
    issue_type = constants.FNX_ERROR

    def validate(self):
        shader_nodes = utils.get_fnx_multi_shaders()
        if len(shader_nodes) <= 1:
            return True

        num_node_colorway_indices = shader_nodes[0].num_inputs
        for node in shader_nodes[1:]:
            if node.num_inputs != num_node_colorway_indices:
                return False

        return True


class FNXSavedSceneValidator(FNXBaseValidator):

    name = "Scene has not been saved."
    issue_type = constants.FNX_ERROR

    def validate(self):
        return bpy.data.is_saved

class FNXConnectRunningValidator(FNXBaseValidator):

    name = "FNX Connect is not running."
    issue_type = constants.FNX_ERROR

    def validate(self):
        connect_status = pl_utils.get_connect_status()
        return not connect_status.error