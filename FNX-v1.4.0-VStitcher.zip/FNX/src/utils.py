import datetime
import json
import math
import os
import random
import re
import subprocess
import string
import tempfile
import time
import unicodedata
import functools

from collections import defaultdict
from copy import deepcopy
from pathlib import Path
from zipfile import ZipFile

import BwApi


INVCHARS_PATTERN = re.compile(r"""[~`!@#$%\^\&\*()+=\\|;<>",?\/'\. {}:-]""", 
                              re.IGNORECASE)
SUBMITTER_CHECK = 'SUBMITTER_CHECK'
GARMENT_CHECK = 'GARMENT_CHECK'
INVALID_CHARS_CHECK = 'INVALID_CHARS_CHECK'
TEMP_SNAPSHOT_ID = "fnx_temporary"


class FnxException(Exception):
    def __init__(self, message):
        super().__init__(message)


def fnx_handle_error(function):
    """A decorator that wraps the passed in function and 
    and raises a FnxException if there was an BwApi error.
    """
    error_codes = {
         0: 'BW_API_ERROR_SUCCESS',
        -1: 'BW_API_ERROR_UNDEFINED',
        -2: 'BW_API_ERROR_INTERNAL_ERROR',
        -3: 'BW_API_ERROR_PARAMS_INVALID',
        -4: 'BW_API_ERROR_INVALID_GARMENT',
        -5: 'BW_API_ERROR_GARMENT_ID_MISMATCH',
        -6: 'BW_API_ERROR_GARMENT_SIZE',
        -7: 'BW_API_ERROR_OBJECT_CREATION_FAILED',
        -8: 'BW_API_ERROR_OBJECT_DELETION_FAILED',
        -9: 'BW_API_ERROR_EDGE_POINTS_METHOD',
        -10: 'BW_API_ERROR_PARAMETER_NOT_FOUND',
        -11: 'BW_API_ERROR_SIZE_MISMATCH',
        -12: 'BW_API_ERROR_SYMMETRY',
        -13: 'BW_API_ERROR_RENAMING_FAILED',
        -14: 'BW_API_ERROR_POINT_CREATION_FAILED',
        -15: 'BW_API_ERROR_USER_DATA_KEY_INVALID',
        -16: 'BW_API_ERROR_OBJECT_NOT_FOUND',
        -17: 'BW_API_ERROR_WRONG_POINT_TYPE',
        -18: 'BW_API_ERROR_INVALID_CONTEXT',
        -19: 'BW_API_ERROR_SHAPE_INCOMPLETE',
        -20: 'BW_API_ERROR_INVALID_IDENTIFIER',
        -21: 'BW_API_ERROR_DEPRECATED_FUNCTION',
        -22: 'BW_API_ERROR_SET_MATERIAL_WRONG_TYPE',
        -23: 'BW_API_ERROR_LICENSE_INSUFFICIENT',
        -24: 'BW_API_ERROR_MATERIAL_TYPE_IS_GROUP_MATERIAL',
        -25: 'BW_API_ERROR_USER_ACTION_ONLY',
        -26: 'BW_API_ERROR_NO_SNAPSHOT_AVAILABLE',
        -27: 'BW_API_ERROR_API_NOT_SUPPORTED'
    }

    @functools.wraps(function)
    def wrapper(*args, **kwargs):
        ret_val = function(*args, **kwargs)
        last_error = BwApi.GetLastError()
        if last_error == BwApi.BW_API_ERROR_SUCCESS:
            return ret_val
        
        error = error_codes.get(last_error, 'error undefined')
        message = error.strip('BW_API_').replace('_', ' ').lower()

        if last_error == BwApi.BW_API_ERROR_NO_SNAPSHOT_AVAILABLE:
            message = "No snapshot is loaded. The avatar should be dressed first."

        raise FnxException(message)

    return wrapper

def quaternion_to_euler(x, y, z, w):
    """Convert Quaternion angles to Euler angles

    :param x: X coordinate
    :type x: int
    :param y: X coordinate
    :type y: int
    :param z: X coordinate
    :type z: int
    :param w: X coordinate
    :type w: int
    :return: XYZ angle rotation
    :rtype: list
    """

    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(t0, t1)
    t2 = +2.0 * (w * y - z * x)
    t2 = +1.0 if t2 > +1.0 else t2
    t2 = -1.0 if t2 < -1.0 else t2
    pitch = math.asin(t2)
    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    half_pi = math.pi/2
    # yaw = 4*math.atan2(t3, t4)
    yaw = math.atan2(t3, t4)
    yaw = half_pi+yaw

    return [yaw, roll, pitch]

def get_output_temp_dir(name=None):
    dir_name = name or current_time()
    out_dir = (
        Path(tempfile.gettempdir()) /
        'fnx_vstitcher_export' /
        dir_name
    )

    return out_dir

def current_time(pretty=False):
    """ Return current date and time
    :return: representation of current time and date, Ex: 2017_05_18_11_01_48
    :rtype: str
    """

    if pretty:
        return datetime.datetime.now().strftime('%m/%d/%Y - %H:%M:%S')

    return datetime.datetime.now().strftime('%Y_%m_%d_%H_%M_%S')

def get_avatar_name():
    # Oddly, the BwApi.AvatarCurrentGet method returns an avatar name that's
    # different from the name in the BwApi.AvatarPropertiesGet method.
    # Therefore, here we attempt to match the name in FBX-imported Blender scene.
    avatar_name = json.loads(BwApi.AvatarPropertiesGet()).get('name')
    if not avatar_name:
        current_avatar = BwApi.AvatarCurrentGet()
        parts = current_avatar.split('_')
        first_part = parts.pop(0)
        try:
            next_idx = parts.index(first_part)
            avatar_name = '_'.join(parts[next_idx:])
        except:
            avatar_name = current_avatar
    return avatar_name

# \todo: We need to come up with a more unified way to sanitize string data.
def remove_control_characters(string: str) -> str:
    """Remove only control characters from the given string."""
    return "".join(ch for ch in string if unicodedata.category(ch)[0] != "C")


def sanitize_name(word: str) -> str:
    """Remove the illegal/invalid character from the given name and return
    encoded strings.
    .. code-block:: python
       >>> print sanitize_name("some pt^&%###% !@#$%^- .21358 Else and _Mor")
       ... "somept21358Elseand_Mor"
       >>> print sanitize_name("╡╡╖╣└╠┐°╗τf_COL_R255_G255_B255_DESATURATION")
       ... "UUUUUUUUUUf_COL_R255_G255_B255_DESATURATION"
       >>> print sanitize_name(r'┐⌐└┌ TEE,PT@3x_4cm')
       ... "NNNNTEEPT3x_4cm"
    :type word: str
    :param word: string to be sanitized
    :rtype: str
    :return: sanitized name
    """
    if not all(ord(_) < 128 for _ in word):
        # removing any possible ascii character
        word = word.encode("ascii", "replace").decode("utf-8")

        # since the above code will replace any invalid character with "?" we
        # are going to replace them with a random character
        word = word.replace("?", random.choice(string.ascii_uppercase))

    # replace unwanted characters
    word = INVCHARS_PATTERN.sub('', word)
    word = word.strip()

    return word


def camel_case(word, chars_to_replace=' '):
    """
    :param word:
    :param chars_to_replace:
    :return:
    """

    new_name = ''

    words = word.split(chars_to_replace)

    if len(words) > 1:
        # capitalize each word and assemble new name
        for word in words:
            new_name = '{}{}'.format(new_name, word.capitalize())
    else:
        new_name = ''.join(words)
        # is it already capitalized?
        if new_name != new_name.lower() and new_name != new_name.upper():
            pass
        # capitalized it
        else:
            new_name = new_name.capitalize()

    return new_name


def find_submitter() -> Path:
    """Find the Submitter executable by checking the environment variable FNX_SUBMITTER_APP first, then PATH, then
    defaults to /usr/local/blender/blender.

    Throws if it can't find the file.
    """
    submitter_exe_path = os.environ.get('FNX_SUBMITTER_APP')
    if not submitter_exe_path:
        msg = ("FNX Submitter v0.12.0 (or higher) was not found on your system. "
                "Please ask your system administrator to set "
                "the environment variable 'FNX_SUBMITTER_APP' to the FNX "
                "Submitter executable path.\nSaving your work and "
                "restarting VStitcher is required.")
        raise Exception(msg)
    elif not Path(submitter_exe_path).exists():
        msg = (f"Environment variable 'FNX_SUBMITTER_APP' is set to '{submitter_exe_path}' "
               "but this path does not exist on your system. Please ask "
               "your system administrator to correctly set " 
               "the executable's path.\nSaving your work and "
               "restarting VStitcher is required.")
        raise Exception(msg)
    
    return Path(submitter_exe_path)


@fnx_handle_error
def render_camera_views(out_path: Path, garment_id: str, camera_views: list, width: int, height: int, include_avatar=False):
    captures = []
    camera_datas = enumerate(get_camera_datas(garment_id, camera_views))
    for index, camera_data in camera_datas:
        # Note: VStitcher's render.json schema and camera.json schema do not validate 
        #       against properties "camera_name", and "width" and "height", respectively.
        #       Therefore, let's add these values in the render params so we could
        #       use them in writing to the FNX Connect config file.
        camera_name = camera_views[index]
        capture = {
            "camera": camera_data,
            "path": str(out_path / f"{camera_name}.png"),
            "camera_name": camera_name
        }
        captures.append(capture)

    render_params = {
        "render": {
            "normal": {
                "outline": False,
                "background": "transparent"
            }
        },
        "include_avatar": include_avatar,
        "width": width,
        "height": height,
        "captures": captures
    }

    BwApi.RenderImage(garment_id, json.dumps(render_params))

    return render_params


def get_camera_datas(garment_id: str, camera_views: list):
    """Get camera data for each of the camera views in the scene.
    """
    for camera_view in camera_views:
        cam_data_str = BwApi.EnvironmentCameraViewGet(garment_id, camera_view)
        camera_data = json.loads(cam_data_str)
        yield camera_data


def run_submitter(asset_path=None, dry_run=False):
    """Run the FNX Connect app with the provided asset path. 
    
    Args:
      asset_path (Path): The asset path, particulary the fnxc.config file.
      dry_run (bool): Print out the full command. Default runs the command.

    Returns:
      Path: The path to the file created in the conversion.
    """
    submitter_exe_path = find_submitter()
    cmd = [str(submitter_exe_path)]

    if asset_path:
        cmd.extend(["submitRender", str(asset_path)])
    if dry_run:
        cmd_str = ' '.join(cmd)
        print(cmd_str)
        return cmd_str
    else:
        subprocess.Popen(cmd, shell=False)


def get_all_file_paths(directory:str)->'list of strings':
    """Recursively get all file paths in directory.

    :param str base_dir: Directory path.
    :return: All file paths under directory.
    :rtype: list[str]
    """
    # Initializing empty file paths list 
    file_paths = [] 

    # Crawling through directory and subdirectories 
    for root, _, files in os.walk(directory): 
        for filename in files: 
            # Join the two strings in order to form the full filepath. 
            filepath = str(Path(root)/filename)
            file_paths.append(filepath) 

    # Returning all file paths 
    return file_paths	

def zip_dir(base_dir:str, out_file:str)->None: 
    """Zip a directory, maintaining relative paths of subdirectories.

    :param base_dir: Path of directory to zip.
    :type base_dir: str
    :param out_file: Path of the resulting zip file.
    :type out_file: str
    """
    file_paths = get_all_file_paths(base_dir)
    
    with ZipFile(out_file,'w') as zip: 
        for file_path in file_paths: 
            relative_path = file_path[len(base_dir) + 1:]
            zip.write(file_path, relative_path)


def get_materials(garment_id=None, colorway_id=None):
    garment_id = garment_id or BwApi.GarmentId()
    colorway_id = BwApi.ColorwayCurrentGet(garment_id)
    material_ids = BwApi.ColorwayMaterialIds(garment_id, colorway_id)
    for material_id in material_ids:
        mat_data_str = BwApi.MaterialGet(garment_id, colorway_id, material_id)
        if not mat_data_str:
            print(f"Retrieved empty data for material {material_id}. Skipping.")
            continue
        material_data = json.loads(remove_control_characters(mat_data_str))
        yield material_data, material_id


def get_invalid_materials(garment_id=None, names_only=False):
    invalid_names = []
    for material, material_id in get_materials(garment_id):
        material_name = material.get('material', {}).get('name', 'nil')
        if re.search(INVCHARS_PATTERN, material_name):
            invalid_names.append(material_name if names_only else (material, material_id))
            
    return invalid_names


def sanitize_names(garment_id=None, colorway_id=None):
    garment_id = garment_id or BwApi.GarmentId()
    colorway_id = BwApi.ColorwayCurrentGet(garment_id)
    original_materials = defaultdict(dict)
    for material, material_id in get_invalid_materials(garment_id):
        original_materials[material_id] = deepcopy(material)
        material_name = material.get('material', {}).get('name', 'nil')
        sanitized_name = sanitize_name(material_name)
        material['material']['name'] = sanitized_name
        BwApi.MaterialUpdate(garment_id, colorway_id, material_id, json.dumps(material))
    
    return original_materials


def update_materials(materials: dict, garment_id=None, colorway_id=None):
    """Updates the materials in the scene.

    Args:
        materials (dict): Dictionary with keys that are the material IDs (int)
                          and values that are JSON-formatted dictionaries returned
                          from BwApi.MaterialGet method.
        garment_id (str): Garment ID. Default is current garment ID.
        colorway_id (str): Colorway ID. Default is current colorway ID from current garment.
    """
    garment_id = garment_id or BwApi.GarmentId()
    colorway_id = BwApi.ColorwayCurrentGet(garment_id)
    for material_id, material in materials.items():
        BwApi.MaterialUpdate(garment_id, colorway_id, material_id, json.dumps(material))


def open_project(garment_path, discard_changes=False):
    garment_id = BwApi.GarmentId()
    BwApi.GarmentClose(garment_id, discardChanges=discard_changes)
    BwApi.GarmentOpen(str(garment_path))
    new_gid = BwApi.GarmentId()
    if TEMP_SNAPSHOT_ID in BwApi.GarmentSnapshotIds(new_gid):
        BwApi.SnapshotDelete(new_gid, TEMP_SNAPSHOT_ID)
        

def save_as_new_project(project_path):
    garment_id = BwApi.GarmentId()
    colorway_id = BwApi.ColorwayCurrentGet(garment_id)
    BwApi.SnapshotSave(garment_id, TEMP_SNAPSHOT_ID)
    
    if not project_path.parent.exists():
        project_path.parent.mkdir(parents=True)

    BwApi.GarmentSaveAs(garment_id, str(project_path))
    gid = BwApi.GarmentId()
    BwApi.ColorwayCurrentSet(gid, colorway_id)
    BwApi.SnapshotLoad(gid, TEMP_SNAPSHOT_ID)


def get_project_path(garment_id=None) -> Path:
    """Gets the garment's project file path.

    Args:
        garment_id (`str`): Garment ID. Defaults to None.

    Returns:
        `Path`: File path of the current project.
    """
    garment_id = garment_id or BwApi.GarmentId()
    garment_path = Path(BwApi.GarmentPathGet(garment_id))

    # prior to version 2020.50591 the project path was pointing to sqlite, but
    # since this version it is actually pointing to .bw file path. so this check
    # would make sure this plugin is backward compatible
    if garment_path.name == '__bwsqlitefoler__':
        garment_path = garment_path.parent

    return garment_path


def do_checks(garment_id):

    try:
        find_submitter()
    except Exception as error:
        return SUBMITTER_CHECK, str(error)

    if not garment_id:
        message = "No garment found."
        return GARMENT_CHECK, message

    # Check if project file is a .bw file
    garment_path = get_project_path(garment_id)
    if not garment_path.suffix == '.bw':
        message = ("Project file not supported.\n\n"
                   "Save project as .bw file before "
                   "submitting garment to FNX.")
        return GARMENT_CHECK, message

    invalid_names = get_invalid_materials(garment_id, names_only=True)
    if invalid_names:
        return INVALID_CHARS_CHECK, "Invalid material names."

    return None, ''


if __name__ == '__main__':
    print(__doc__)
