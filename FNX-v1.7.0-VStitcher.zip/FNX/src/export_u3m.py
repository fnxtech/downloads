import json
import os
import re
import sys
import tempfile
import traceback

from os import path, makedirs
from pathlib import Path

import BwApi
from zipfile import ZipFile

sys.path.insert(0, path.abspath(__file__))

from logger import get_logger
from utils import sanitize_name, current_time, remove_control_characters

LOGGER = get_logger(__name__)


def export_u3m(garment_id, output_dir=None, current_colorway=False):
    """Export all materials from all colorways as U3M into a temp location

    :param garment_id: id of the current garment
    :type garment_id: int
    :rtype: str
    :return: path to the temp location that U3Ms have been exported
    """
    if output_dir:
        temp_location = path.join(output_dir, 'U3M_out')
    else:
        temp_location = path.join(tempfile.gettempdir(),
                                'export_colorways_u3m',
                                current_time())

    if not path.exists(temp_location):
        makedirs(temp_location)
    u3m_file_paths = []


    # get all colorways
    if current_colorway:
        colorway_ids = (BwApi.ColorwayCurrentGet(garment_id),)
    else:
        colorway_ids = BwApi.GarmentColorwayIds(garment_id)

    for colorway_id in colorway_ids:
        BwApi.ColorwayCurrentSet(garment_id, colorway_id)
        colorway_name = BwApi.ColorwayNameGet(garment_id, colorway_id)
        colorway_root = path.join(temp_location, sanitize_name(colorway_name))

        LOGGER.info("Processing {} colorway with ID: "
                    "{}".format(colorway_name, colorway_id))

        material_ids = BwApi.ColorwayMaterialIds(garment_id,
                                                 colorway_id)

        # get all materials in the this colorways
        for material_id in material_ids:
            material_json = BwApi.MaterialGet(garment_id,
                                              colorway_id,
                                              material_id)
            if not material_json:
                continue
            mtl_str = json.dumps(material_json)
            LOGGER.info("*** Material ID {}: {}".format(material_id, mtl_str))
            material_data = json.loads(remove_control_characters(material_json))
            u3m_file_name = material_data.get('material', {}).get('name')
            
            if not u3m_file_name:
                u3m_file_name = "{}_{}_{}".format(
                    garment_id,
                    colorway_id,
                    material_id
                )
                LOGGER.warning('Failed to find the material name. Constructing'
                               'a default name: {}'.format(u3m_file_name))
            else:
                u3m_file_name = sanitize_name(u3m_file_name)

            u3m_root = path.join(colorway_root, u3m_file_name)
            u3ma_file_path = Path(u3m_root)/(u3m_file_name + ".u3ma")

            # Export .u3ma archive, extract it, remove archive.
            # NOTE: Passing in a *.u3m path does not export anything (as of August Edition),
            #       which may be the intended behaviour or an API bug.
            #       However, passing in a *.u3ma path does export an archived 
            #       file contained with the u3m + textures.
            # TODO: Remove these extra processes if/when .u3m export is supported.
            BwApi.MaterialExport(garment_id, colorway_id, material_id, u3ma_file_path.as_posix())
            extract_u3ma(u3ma_file_path)
            os.remove(u3ma_file_path)
            u3m_file_path = u3ma_file_path.parent/(u3ma_file_path.stem + ".u3m")
            u3m_file_paths.append(u3m_file_path.as_posix())
    
    return (temp_location, u3m_file_paths)


def extract_u3ma(file_path: Path):
    u3m_basepath = file_path.parent
    with ZipFile(file_path.as_posix(), 'r') as zipfile:
        zipfile.extractall(u3m_basepath.as_posix())