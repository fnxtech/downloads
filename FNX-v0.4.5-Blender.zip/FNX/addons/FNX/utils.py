# Blender
import bpy

# FNX
from . import constants

# plugin-libs
from .plugin_libs.fnx_plugin_libs.logger import get_logger

LOGGER = get_logger(__name__)


def get_fnx_scene_cameras():
    """
    Get all FNX cameras.

    Returns:

    """
    return [
        obj
        for obj in bpy.data.objects
        if obj.type == constants.BLENDER__CAMERA_TYPE_NAME
        and obj.name.startswith(constants.FNX_BLENDER__CAMERA_NAME_PREFIX)
    ]


def get_fnx_multi_shaders():
    """
    Get FNX shader nodes.

    Returns:
        list of FNX shader nodes

    """
    fnx_shaders = []
    for mat in bpy.data.materials:
        if not mat.node_tree:
            continue

        shader_nodes = mat.node_tree.nodes
        for node in shader_nodes:
            try:
                if node.bl_name == constants.FNX_BLENDER__MULTI_SHADER_NODE_NAME:
                    fnx_shaders.append(node)
            except AttributeError:
                pass

    return fnx_shaders


def get_garment_materials():
    """Get all geometry in the FNX_GARMENT collection and find all their materials."""

    geo_collection = bpy.data.collections[constants.FNX_BLENDER__GARMENT_COLLECTION_NAME]

    all_materials = set()

    for obj in geo_collection.objects:
        if obj.type == constants.BLENDER__MESH_TYPE_NAME:
            mat = obj.active_material
            if not mat.node_tree:
                continue

            all_materials.add(mat)

    return all_materials
