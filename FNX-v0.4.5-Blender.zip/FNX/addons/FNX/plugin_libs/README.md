# FNX Plugin Libraries

Shared FNX plugin functionality used by our various DCC plugins.

### Python 2 Compatibility

Due to Modo supporting Python 2.7.14, we have to ensure Python 2 backwards compatibility.

In order to enforce this, we run Pylint with Python 2 on all code before committing.  For convenience,
please use the pre-commit hook from the `.githooks` directory by running the following:

`git config --local core.hooksPath .githooks/`

**N.B.** You should have Python 2 installed and the executable aliased to `python2`.
