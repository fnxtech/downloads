"""FNX Blender plugin exceptions."""


class FNXException(Exception):
    """FNX base exception."""


class NoConfigException(Exception):
    """No config exception."""

    _MESSAGE = "No config.  Cannot submit job."

    def __str__(self):
        return NoConfigException._MESSAGE


class SubmitException(Exception):
    """Submit error exception."""

    _MESSAGE = "Error running submitter: "

    def __init__(self, exception):
        super(SubmitException, self).__init__()
        self._message = SubmitException._MESSAGE + str(exception)

    def __str__(self):
        return self._message


FNXExceptions = (
    FNXException,
    NoConfigException,
    SubmitException,
)
