"""
N.B.  This should be backwards compatible for Python 2.x as Modo is still on Python 2.7.
"""

# Python
import json
import os
import shutil
import tempfile
from datetime import datetime, timedelta

try:
    from pathlib import Path
except ImportError:
    # Python 2.x compatibility library
    # N.B. We can pip install pathlib2 but some DCC's (e.g. Modo) have closed Python so cannot
    from .externals.pathlib2 import Path

# from typing import Generator

# plugins-libs
from . import constants
from . import exceptions
from .logger import get_logger

LOGGER = get_logger(__name__)

_CONFIG_VERSION = 2
"""Use a config version for Connect."""


def get_temp_dir(temp_dir_name):
    temp_dir = Path(tempfile.gettempdir()) / temp_dir_name

    return temp_dir


def create_output_temp_dir(temp_dir_name, name=None):
    dir_name = name or current_time()
    out_dir = get_temp_dir(temp_dir_name) / dir_name
    out_dir.mkdir(exist_ok=True, parents=True)
    return out_dir


def get_temp_bundles(temp_dir_name, days_delta=0):
    """Get the paths of bundles exported to the temporary folder
    that are older than the number of days given.

    Args:
        days_delta: Minimum number of elapsed days since folder was created.
    Returns:
        Generator: Yields Path objects.
    """
    temp_dir = get_temp_dir(temp_dir_name)
    if not temp_dir.exists():
        return

    for bundle_path in temp_dir.iterdir():
        created = os.path.getctime(bundle_path)
        age = datetime.now() - datetime.fromtimestamp(created)
        if age > timedelta(days=days_delta):
            yield bundle_path


def remove_temp_files(temp_dir_name, days_delta=0):
    """Removes bundles which were exported the temporary folder
    that are older than the maximum given age.

    Args:
        days_delta: Minimum number of elapsed days since folder was created.

    Returns:
        [Path]: List of removed bundle paths.
    """
    removed_bundles = []
    for bundle_path in get_temp_bundles(temp_dir_name, days_delta):
        shutil.rmtree(bundle_path)
        removed_bundles.append(bundle_path)

    return removed_bundles


def current_time(pretty=False):
    """ Return current date and time
    :return: representation of current time and date, Ex: 2017_05_18_11_01_48
    :rtype: str
    """

    if pretty:
        return datetime.now().strftime('%m/%d/%Y - %H:%M:%S')

    return datetime.now().strftime('%Y_%m_%d_%H_%M_%S')


def export_submit_config(output_dir, project_path, project_name, custom_cameras, dcc_dict, scene_data,
                         beproduct_render=True, geo_export=None):
    """
    Generate and write config file that drives FNX Connect.

    Args:
        output_dir (Path): the output directory for the config file
        project_path (Path): the path to the project file
        project_name (str): the project name
        custom_cameras (dict): a dictionary of custom camera data
        dcc_dict (dict): dictionary of DCC settings
        scene_data (dict): dictionary of scene data
        beproduct_render (bool): whether to export beproduct
        geo_export (dict): optional dictionary of geometry export options

    Returns:

        the path to the config file

    """
    # Load plugin info - check parents
    plugin_json = None
    for idx in range(0, 4):
        potential_plugin_json = Path(__file__).parents[idx] / "plugin.json"
        if potential_plugin_json.exists():
            plugin_json = potential_plugin_json
            break

    if not plugin_json:
        raise exceptions.FNXException("Could not locate plugin.json file.")

    with open(str(plugin_json), "r") as pjson:
        plugin_dict = json.load(pjson)
        plugin_dict["api_version"] = str(plugin_dict.get("api_version", 0.0))

    fnxc_config = {
        "config_version": _CONFIG_VERSION,
        "custom_cameras": custom_cameras,
        "data": str(output_dir),
        "project_file": project_path.as_posix(),
        "project_name": project_name,
        "dcc": dcc_dict,
        "plugin": plugin_dict,
        "scene_data": scene_data
    }

    if beproduct_render:
        fnxc_config["additional_files"] = {"beproduct_render_blender": [project_path.as_posix()]}

    if geo_export:
        fnxc_config["geo_export"] = geo_export

    fnxc_config_file = output_dir / constants.FNX_CONFIG_FILE
    with open(str(fnxc_config_file), "w") as file_handle:
        json.dump(fnxc_config, file_handle, indent=2)

    return fnxc_config_file
