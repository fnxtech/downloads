"""
N.B.  This should be backwards compatible for Python 2.x as Modo is still on Python 2.7.
"""

# Python
import json
import time
from collections import namedtuple

try:
    from urllib.request import urlopen
    from urllib import parse
    from urllib.error import URLError, HTTPError
except ImportError:
    # Python 2.x backwards compatibility
    import urllib as parse
    from urllib2 import URLError, HTTPError

    # Add context wrapper for urlopen
    from contextlib import closing
    from urllib2 import urlopen as _urlopen
    def urlopen(*args, **kwargs):
        return closing(_urlopen(*args, **kwargs))

try:
    from pathlib import Path
except ImportError:
    # Python 2.x compatibility library
    # N.B. We can pip install pathlib2 but some DCC's (e.g. Modo) have closed Python so cannot
    from .externals.pathlib2 import Path

# from typing import Generator

# plugins-libs
from . import constants
from . import exceptions
from .logger import get_logger

LOGGER = get_logger(__name__)

_CONNECT_HOST = "localhost"
"""FNX Connect host name"""

_CONNECT_PORT = 40391
"""FNX Connect port number"""

_CONNECT_URL = "http://%s:%s" % (_CONNECT_HOST, _CONNECT_PORT)
"""FNX Connect http request url"""

FNXConnectStatus = namedtuple("FNXConnectStatus", ["message", "error"])
"""Health status of FNX Connect"""

FNXConnectResponse = namedtuple("FNXConnectResponse", ["message", "error", "data"])
"""HTTP resonpse from FNX Connect"""


def get_session_params(session_id):
    """Http request to get the job parameters that were set in Connect.

    Returns:
        FNXConnectResponse: namedtuple with attributes `message`, `error`, and `data`
    """
    connect_status = get_connect_status()
    if connect_status.error:
        raise exceptions.FNXException(connect_status.message)

    parameters = {
        "sessionId": session_id,
    }

    url_parameters = parse.urlencode(parameters)
    data = url_parameters.encode('ascii')
    url = "%s/get-session-params" % _CONNECT_URL
    params = {}
    try:
        with urlopen(url, data) as f:
            response = f.read().decode("utf-8")
            print(f.read())
            params = json.loads(response)
            LOGGER.debug("request FNX Connect: %s" % str(params))
        return FNXConnectResponse(message="session parameters ready", error="", data=params)

    except URLError as error:
        LOGGER.error("/get-session-params: %s" % str(error.reason))
        return FNXConnectResponse(message="session was aborted", error=error.reason, data=params)


def is_session_window_visible(session_id):
    """Check whether the session's window is open and visible.

    Returns:
        FNXConnectResponse: namedtuple with attributes `message`, `error`, and `data`
    """
    url = "%s/status/session-window-visible" % _CONNECT_URL
    parameters = {
        "sessionId": session_id,
    }
    url_parameters = parse.urlencode(parameters)
    data = url_parameters.encode('ascii')
    try:
        with urlopen(url, data) as f:
            response = f.read().decode("utf-8") == "OK"
        return FNXConnectResponse(message="session window is open", error="", data=response)

    except URLError as error:
        return FNXConnectResponse(message="session is not available", error=error.reason, data=False)


def get_connect_status(): #  -> FNXConnectStatus:
    """Get the health status of FNX Connect.
    If attribute `error` is not an empty string, then Connect is not running
    or there's another issue as indicated by the http response.

    Returns:
        FNXConnectStatus: namedtuple with attributes `message` and `error`
    """
    url = "%s/status/alive" % _CONNECT_URL
    try:
        with urlopen(url) as f:
            response = f.read().decode("utf-8")
            error = "" if response == "OK" else response
        return FNXConnectStatus(message=response, error=error)

    except URLError as error:
        return FNXConnectStatus(message="FNX Connect is not running", error=error.reason)


def submit_render(session_id):
    """Http request to submit the session's jobs.

    Args:
      session_id (str): ID of the submission session.

    Returns:
        FNXConnectResponse: namedtuple with attributes `message`, `error`, and `data`

    Raises:
        FNXException: If FNX Connect is not alive.
    """
    connect_status = get_connect_status()
    if connect_status.error:
        raise exceptions.FNXException(connect_status.message)

    parameters = {
        "sessionId": session_id,
    }

    url_parameters = parse.urlencode(parameters)
    data = url_parameters.encode('ascii')
    url = "%s/render-submit" % _CONNECT_URL
    try:
        with urlopen(url, data) as f:
            response = f.read().decode("utf-8")
            error = "" if response == "Render submitted" else response
            LOGGER.info("FNX Connect: %s" % response)
        return FNXConnectResponse(message="submitted render job", error="", data=response)

    except URLError as error:
        LOGGER.error("/render-submit: %s" % str(error.reason))
        return FNXConnectResponse(message="failed to submit render job", error=error.reason, data="")


def launch_session(
        asset_path,
        is_batch=False,
        async_submit=False,
        action_type=constants.FNX_SUBMISSION_TYPE_BUNDLE,
        timeout=constants.FNX_SUBMITTER_TIMEOUT):
    """Launches a new FNX Connect submission window with the given config file.

    Args:
      asset_path (Path): The asset path, particulary the fnx.config file.
      is_batch (bool): Whether the jobs are submitted in batch or as a single job.
      async_submit (bool): If True, resources (i.e. geometry, scene file) are created
                           after launching the session, and submitting must be
                           explicitly called (see `submit_render` function).
                           Otherwise, resources must be created before launching session.
      action_type (str): One of [constants.FNX_SUBMISSION_TYPE_BUNDLE, constants.FNX_SUBMISSION_TYPE_VRAY].
                         Default is constants.FNX_SUBMISSION_TYPE_BUNDLE
      timeout (int): Number of milliseconds to wait until the submitter window is open.
                        Default is constants.FNX_SUBMITTER_TIMEOUT.

    Returns:
        str: The new session's ID which is typically needed in downstream request calls.

    Raises:
        FNXException: If FNX Connect is not alive.
    """
    connect_status = get_connect_status()
    if connect_status.error:
        raise exceptions.FNXException(connect_status.message)

    parameters = {
        "action": action_type,
        "configFile": asset_path.as_posix(),
        "isAsync": "true" if async_submit else "false"
    }

    if is_batch:
        parameters["batch"] = "true"

    url_parameters = parse.urlencode(parameters)
    data = url_parameters.encode('ascii')
    url = "%s/launch-session" % _CONNECT_URL
    session_id = None
    try:
        with urlopen(url, data) as f:
            session_id = f.read().decode('utf-8')
            LOGGER.debug("Opened FNX Connect session: %s" % str(session_id))
    except HTTPError as e:
        msg = str(e.reason)
        if e.getcode() == 409:
            msg = "Connect needs to be updated first"
        LOGGER.error(msg)
        raise exceptions.FNXException("FNX Connect: %s" % msg)

    # Return when session is ready and window is visible
    response = is_session_window_visible(session_id)
    t0 = time.time()
    # TODO: thread this so you can have a pop-up indicating that you are waiting on connect
    while not response.data:
        response = is_session_window_visible(session_id)
        time.sleep(1.0)
        if ((time.time() - t0) > timeout):
            message = "FNX Connect - Submission window failed launch after %sms" % str(timeout)
            raise exceptions.FNXException(message)

    return session_id

def show_info_dialog(session_id, message, show, progress=None):
    """Http request to show an informational dialg with a progress bar in Connect.
    This dialog cannot be closed by the user but should be programmatically handled.

    Args:
        session_id (str): Session ID of the submissions session in Connect.
        message (str): Text shown in the dialog contents.
        show (bool): Show dialog if True, otherwise, hide it.
        progress (None or int): Percent value in progress bar. If None, show indeterminate progress.

    Returns:
        FNXConnectResponse: namedtuple with attributes `message`, `error`, and `data`
    """
    connect_status = get_connect_status()
    if connect_status.error:
        raise exceptions.FNXException(connect_status.message)

    parameters = {
        "sessionId": session_id,
        "message" : message,
        "show": "true" if show else "false"
    }
    if progress:
        parameters["progress"] = str(progress)

    url_parameters = parse.urlencode(parameters)
    data = url_parameters.encode('ascii')
    url = "%s/show-session-dialog" % _CONNECT_URL
    try:
        with urlopen(url, data) as f:
            response = f.read().decode("utf-8") == "OK"
            msg = "show dialog" if show else "hide dialog"
        return FNXConnectResponse(message=msg, error="", data=response)

    except URLError as error:
        return FNXConnectResponse(message="session is not available", error=error.reason, data=False)


def close_session(session_id):
    """Http request to close the given Connect session and its submission window.

    Args:
      session_id (str): ID of the submission session in Connect.

    Returns:
      FNXConnectResponse: namedtuple with attributes `message`, `error`, and `data`

    Raises:
        FNXException: If FNX Connect is not alive.
    """
    connect_status = get_connect_status()
    if connect_status.error:
        raise exceptions.FNXException(connect_status.message)

    response = is_session_window_visible(session_id)
    if not response.data:
        msg = "{}: {}".format(str(response.message), str(response.error))
        raise exceptions.FNXException(msg)

    parameters = {
        "sessionId": session_id,
    }

    url_parameters = parse.urlencode(parameters)
    data = url_parameters.encode('ascii')
    url = "%s/close-session" % _CONNECT_URL
    with urlopen(url, data) as f:
        response = f.read().decode('utf-8')

    return FNXConnectResponse(message="Closed session", error="", data=response)
