from pathlib import Path
import pytest

# FNX:
from fnx_plugin_libs import exceptions
from fnx_plugin_libs import connect


def test_get_session_params():

    with pytest.raises(exceptions.FNXException):
        connect.get_session_params(1234)


def test_is_session_window_visible():

    response = connect.is_session_window_visible(1234)

    assert response.message == "session is not available"
    assert response.data is False


def test_get_connect_status():

    response = connect.get_connect_status()
    assert response.message == "FNX Connect is not running"


def test_submit_render():

    with pytest.raises(exceptions.FNXException):
        connect.submit_render(1234)


def test_launch_session():

    with pytest.raises(exceptions.FNXException):
        connect.launch_session(Path("/tmp/bob"))


def test_show_info_dialog():

    with pytest.raises(exceptions.FNXException):
        connect.show_info_dialog(1234, "this is a test", True)


def test_close_session():

    with pytest.raises(exceptions.FNXException):
        connect.close_session(1234)
