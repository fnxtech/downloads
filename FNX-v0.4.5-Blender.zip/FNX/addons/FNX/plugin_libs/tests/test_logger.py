# FNX
from fnx_plugin_libs import logger


def test_get_file_handler():
    file_handler = logger.get_file_handler()
    assert file_handler


def test_get_file_handler__no_temp_folder(mocker):
    mocker.patch('tempfile.gettempdir', return_value="C:\\bob")
    file_handler = logger.get_file_handler()
    assert file_handler
