from pathlib import Path
import json
import re
import pytest

# FNX:
from fnx_plugin_libs import exceptions
from fnx_plugin_libs import utils


def test_get_temp_dir(mocker):
    mocker.patch('tempfile.gettempdir', return_value="C:/tmp")

    tmp_dir = utils.get_temp_dir("test")
    assert tmp_dir.as_posix() == Path("C:/tmp/test").as_posix()


def test_create_output_temp_dir(mocker):
    mocker.patch('tempfile.gettempdir', return_value="C:/tmp")

    tmp_dir = utils.create_output_temp_dir("test", name="bob")
    assert tmp_dir.as_posix() == Path("C:/tmp/test/bob").as_posix()

    tmp_dir = utils.create_output_temp_dir("test")
    assert re.match("C:/tmp/test/\d{4}_\d{2}_\d{2}_\d{2}_\d{2}_\d{2}", str(tmp_dir.as_posix()))


def test_get_temp_bundles():

    bundles = utils.get_temp_bundles("i_do_not_exist")
    assert list(bundles) == []

    output_dir_1 = utils.create_output_temp_dir("test_get", name="bob")
    output_dir_2 = utils.create_output_temp_dir("test_get", name="foo")

    bundles = utils.get_temp_bundles("i_do_not_exist")
    assert list(bundles) == []

    bundles = utils.get_temp_bundles(output_dir_1.parents[0])
    bundles = list(bundles)
    assert output_dir_1 in list(bundles)
    assert output_dir_2 in list(bundles)

    bundles = utils.get_temp_bundles(output_dir_1.parents[0], days_delta=100)
    bundles = list(bundles)
    assert output_dir_1 not in list(bundles)
    assert output_dir_2 not in list(bundles)


def test_remove_temp_files():

    output_dir_1 = utils.create_output_temp_dir("test", name="bob")
    output_dir_2 = utils.create_output_temp_dir("test", name="foo")

    assert output_dir_1.exists()
    assert output_dir_2.exists()

    utils.remove_temp_files(output_dir_1.parents[0])

    assert not output_dir_1.exists()
    assert not output_dir_2.exists()


def test_current_time():

    formatted_time = utils.current_time(pretty=False)
    assert re.match(r"\d{4}_\d{2}_\d{2}_\d{2}_\d{2}_\d{2}", formatted_time)

    formatted_time = utils.current_time(pretty=True)
    assert re.match(r"\d{2}\/\d{2}\/\d{4}\ \-\ \d{2}\:\d{2}\:\d{2}", formatted_time)


def test_export_submit_config(mocker):

    output_dir = utils.create_output_temp_dir("test_export")

    with pytest.raises(exceptions.FNXException):
        utils.export_submit_config(
            output_dir,
            Path("/Path/To/Project/File"),
            "TestProject",
            {},
            {},
            {"scene_data": "test"},
            geo_export={"geo_export": 1234}
        )

    fnxc_config_file = output_dir / "plugin.json"
    with open(str(fnxc_config_file), "w") as file_handle:
        fnxc_config = {
            "api_version": "1.2.3"
        }
        json.dump(fnxc_config, file_handle, indent=2)

    # Mock __file__ magic method so we can use test data
    mocker.patch.object(utils, '__file__', new=output_dir / "ignore")

    config_path = utils.export_submit_config(
        output_dir,
        Path("/Path/To/Project/File"),
        "TestProject",
        {},
        {},
        {"scene_data": "test"},
        geo_export={"geo_export": 1234}
    )

    assert config_path.exists()

    with open(config_path, "r") as file_handle:
        content = json.load(file_handle)

    assert content["data"] == str(output_dir)
    assert content["project_file"] == "/Path/To/Project/File"
    assert "additional_files" in content
    assert "geo_export" in content
