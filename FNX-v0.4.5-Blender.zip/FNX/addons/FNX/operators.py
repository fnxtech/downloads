"""FNX Blender operator addons."""

# Python
import inspect

# Blender
import bpy
from bpy.types import Operator

# FNX
from . import constants
from . import exporter
from . import utils
from . import validation

# plugin-libs
from .plugin_libs.fnx_plugin_libs import exceptions as pl_exceptions
from .plugin_libs.fnx_plugin_libs.logger import get_logger

LOGGER = get_logger(__name__)

READ_ONLY_ATTRIBUTES = ("texture_mapping", "color_mapping", "image_user")
"""Read only shader node attributes."""

DEFAULT_INPUT_ATTRIBUTES = ("default_value", "name")
"""Attributes that should be copied for every link."""

IGNORE_ATTRIBUTES = ("rna_type", "type", "dimensions", "inputs", "outputs", "internal_links", "select", "location")
"""Attributes that should be not be copied for every link."""


def copy_attributes(attributes, source_node, target_node):
    """Copy specified attributes from source node to target node."""
    for source_attr in attributes:
        if hasattr(target_node, source_attr) and source_attr not in READ_ONLY_ATTRIBUTES:
            try:
                setattr(target_node, source_attr, getattr(source_node, source_attr))
            except Exception as ex:
                LOGGER.error(ex)


class FNXCreateTemplateHierarchyOp(Operator):

    bl_idname = "wm.create_template_hierarchy"
    bl_label = "Setup groups"

    def execute(self, context):

        collection = bpy.data.collections.new("FNX_REFERENCES")
        context.scene.collection.children.link(collection)

        # Add FNX_GUIDEBOX

        collection = bpy.data.collections.new("FNX_GARMENT")
        context.scene.collection.children.link(collection)

        collection = bpy.data.collections.new("FNX_AVATAR")
        context.scene.collection.children.link(collection)

        return {'FINISHED'}


class FNXCreateGuideBoxOp(Operator):

    bl_idname = "custom.create_guide_box"
    bl_label = "Create FNX guide box"

    def execute(self, context):

        guide_box_obj = bpy.data.objects.get(constants.FNX_BLENDER__GUIDE_BOX_NAME)

        if guide_box_obj:
            scn = context.scene
            if guide_box_obj.hide_get():
                guide_box_obj.hide_set(state=False)
                scn.fnx_scene_state.guide_box_state = "Hide"
            else:
                guide_box_obj.hide_set(state=True)
                scn.fnx_scene_state.guide_box_state = "Show"

            return {'FINISHED'}

        obj = bpy.data.objects.new(constants.FNX_BLENDER__GUIDE_BOX_NAME, None)
        obj.empty_display_type = 'CUBE'
        obj.scale = (1, 1, 1.6)
        context.scene.collection.objects.link(obj)
        scn = context.scene
        scn.fnx_scene_state.guide_box_state = "Hide"

        return {'FINISHED'}


class BaseFNXColorwaysOp(Operator):
    """Base colorways operator."""

    @classmethod
    def poll(cls, context):
        scn = context.scene
        if scn.fnx_scene_state.errors:
            return False

        return True


class FNXSubmitCurrentColorwaysOp(BaseFNXColorwaysOp):
    """Submit current colorway operator."""

    bl_idname = "render.submit_current_colorway"
    bl_label = "Submit Current Colorway to FNX"
    bl_description = "Submit Current Colorway to FNX"

    def execute(self, context):
        try:
            scn = context.scene
            colorway_index = scn.fnx_scene_state.colorway_index
            exporter.generate_and_submit_bundle(colorway_indices=[colorway_index])
        except pl_exceptions.FNXException as ex:
            LOGGER.error(ex)
            self.report({"ERROR"}, str(ex))

        return {"FINISHED"}


class FNXSubmitAllColorwaysOp(BaseFNXColorwaysOp):
    """Submit all colorways operator."""

    bl_idname = "render.submit_all_colorways"
    bl_label = "Submit All Colorways to FNX"
    bl_description = "Submit All Colorways to FNX"

    def execute(self, _context):
        try:
            shader_nodes = utils.get_fnx_multi_shaders()
            if len(shader_nodes) == 0:
                return

            # All shader nodes have the same number of color indices so just inspect one
            max_colorway_index = shader_nodes[0].num_inputs
            colorway_indices = list(range(0, max_colorway_index))
            exporter.generate_and_submit_bundle(colorway_indices=colorway_indices)
        except pl_exceptions.FNXException as ex:
            LOGGER.error(ex)
            self.report({"ERROR"}, str(ex))

        return {"FINISHED"}


class FNXValidatorOp(Operator):

    bl_idname = "custom.run_validation"
    bl_label = "FNX Scene Validator"

    def _validate(self, context):

        scn = context.scene
        lst = scn.issues

        if len(lst) > 0:
            # reverse range to remove last item first
            for i in range(len(lst) - 1, -1, -1):
                scn.issues.remove(i)

        errors = 0
        warnings = 0
        for name, cls in inspect.getmembers(validation):
            if inspect.isclass(cls):
                obj = cls()
                if issubclass(cls, validation.FNXBaseValidator) and type(obj) != validation.FNXBaseValidator:
                    if not obj.validate():
                        item = scn.issues.add()
                        item.id = len(scn.issues)
                        item.name = obj.name
                        item.validator = name
                        item.issue_type = obj.issue_type
                        if obj.issue_type == constants.FNX_ERROR:
                            errors += 1
                        elif obj.issue_type == constants.FNX_WARNING:
                            warnings += 1

        scn.fnx_scene_state.errors = bool(errors)
        scn.fnx_scene_state.warnings = bool(warnings)

        self.report({'INFO'}, "Validation complete")

    def execute(self, context):

        self._validate(context)

        return {"FINISHED"}

    def invoke(self, context, _event):

        self._validate(context)

        return {"FINISHED"}


class FNXValidatorFixOp(Operator):
    bl_idname = "custom.run_validator_fix"
    bl_label = ""

    validator_name: bpy.props.StringProperty()

    def execute(self, _context):
        class_inst = getattr(validation, self.validator_name)
        class_inst().fix()
        bpy.ops.custom.run_validation()
        return {'FINISHED'}


class BaseFNXAddConnectColorwaysOp(Operator):
    """Base colorways operator."""

    @classmethod
    def poll(cls, _context):

        validator = validation.FNXGarmentCollectionValidator()
        if not validator.validate():
            return False

        validator = validation.FNXGarmentObjectsValidator()
        if not validator.validate():
            return False

        return True


class FNXAddColorwayOp(BaseFNXAddConnectColorwaysOp):

    bl_idname = "custom.add_colorway"
    bl_label = "Add colorway"

    def execute(self, _context):

        for material in utils.get_garment_materials():
            output_node = [node for node in material.node_tree.nodes if node.type == 'OUTPUT_MATERIAL'][0]
            output_surface_input = output_node.inputs['Surface']
            output_surface_input_node = output_surface_input.links[0].from_node

            if output_surface_input_node.type != "CUSTOM GROUP":
                continue

            try:
                if output_surface_input_node.bl_name == constants.FNX_BLENDER__MULTI_SHADER_NODE_NAME:

                    # Copy the connections from the first colorway
                    source_node = None
                    if output_surface_input_node.inputs:
                        links = output_surface_input_node.inputs['Colorway index 0'].links
                        if links:
                            connected_node = links[0].from_node
                            if connected_node.type == constants.BLENDER__BSDF_PRINCIPLED_SHADER_NODE_TYPE:
                                source_node = connected_node

                    # We have found a FNXMultiShader node - add a new BSDF node
                    bsdf_shader_node = material.node_tree.nodes.new(constants.BLENDER__BSDF_PRINCIPLED_SHADER_NODE_NAME)
                    # Set default color
                    bsdf_shader_node.inputs['Base Color'].default_value = constants.FNX_BLENDER__DEFAULT_COLOR
                    # Increment number of inputs
                    output_surface_input_node.num_inputs = output_surface_input_node.num_inputs + 1
                    # Connect new BSDF node -> FNXMultiShader
                    material.node_tree.links.new(
                        bsdf_shader_node.outputs['BSDF'],
                        output_surface_input_node.inputs[output_surface_input_node.num_inputs - 1]
                    )

                    if source_node:
                        node_attributes = []
                        for attr in source_node.bl_rna.properties:
                            if attr.identifier not in IGNORE_ATTRIBUTES and not attr.identifier.split("_")[0] == "bl":
                                node_attributes.append(attr.identifier)

                        copy_attributes(node_attributes, source_node, bsdf_shader_node)

                        # Copy the input attributes
                        for nidx, node_input in enumerate(source_node.inputs):
                            copy_attributes(DEFAULT_INPUT_ATTRIBUTES, node_input, bsdf_shader_node.inputs[nidx])
                            for link in node_input.links:
                                material.node_tree.links.new(link.from_socket, bsdf_shader_node.inputs[nidx])

            except AttributeError:
                pass

        return {'FINISHED'}


class FNXConnectMultiShadersOp(BaseFNXAddConnectColorwaysOp):

    bl_idname = "custom.connect_multi_shaders"
    bl_label = "Connect FNX multi shaders"

    def execute(self, _context):

        for material in utils.get_garment_materials():
            output_node = [node for node in material.node_tree.nodes if node.type == 'OUTPUT_MATERIAL'][0]
            output_surface_input = output_node.inputs['Surface']
            output_surface_input_node = output_surface_input.links[0].from_node

            # We create the node if we do not already have a FNXMultiShader node
            create_new_node = True
            if output_surface_input_node.type == "CUSTOM GROUP":
                try:
                    if output_surface_input_node.bl_name == constants.FNX_BLENDER__MULTI_SHADER_NODE_NAME:
                        create_new_node = False
                except AttributeError:
                    pass

            if not create_new_node:
                continue

            # Get output node connected node
            if 'BSDF' in output_surface_input_node.type:
                output_node_input = output_surface_input_node.outputs['BSDF']
            elif 'SHADER' in output_surface_input_node.type:
                output_node_input = output_surface_input_node.outputs['Shader']
            else:
                LOGGER.warning("Unhandled node output '%s'" % output_surface_input_node.type)
                output_node_input = None

            if output_node_input:
                # Create new FNXMultiShader node
                fnx_multi_shader = material.node_tree.nodes.new(constants.FNX_BLENDER__MULTI_SHADER_NODE_TYPE_NAME)
                # Connect output_node_input -> FNXMultiShader
                material.node_tree.links.new(output_node_input, fnx_multi_shader.inputs[0])
                # Connect FNXMultiShader -> Output material node
                material.node_tree.links.new(fnx_multi_shader.outputs[0], output_node.inputs['Surface'])

        return {'FINISHED'}


OPERATOR_CLASSES = [
    FNXAddColorwayOp,
    FNXCreateTemplateHierarchyOp,
    FNXCreateGuideBoxOp,
    FNXConnectMultiShadersOp,
    FNXSubmitCurrentColorwaysOp,
    FNXSubmitAllColorwaysOp,
    FNXValidatorOp,
    FNXValidatorFixOp,
]
