"""FNX Blender addon."""

# Python
import os

# Blender
import bpy
from bpy.props import IntProperty, CollectionProperty, StringProperty, PointerProperty, FloatProperty, BoolProperty
from bpy.types import Panel, UIList, Menu, PropertyGroup
from bpy.utils import previews
from nodeitems_utils import NodeCategory, NodeItem, register_node_categories, unregister_node_categories
from nodeitems_builtins import ShaderNodeCategory

# plugin-libs
from .plugin_libs.fnx_plugin_libs.logger import get_logger
from .plugin_libs.fnx_plugin_libs import utils as pl_utils

# FNX
from . import constants
from . import utils
from . import validation
from . import operators


LOGGER = get_logger(__name__)


bl_info = {
    "name": "FNX",
    "description": "FNX Blender tool suite",
    "author": "FNX Technologies",
    "version": (0, 1, 0),
    "blender": (2, 80, 3),
    "location": "Scene properties > FNX",
    "warning": "",  # used for warning icon and text in addons panel
    "wiki_url": "",
    "tracker_url": "",
    "category": "Development"
}

preview_collections = {}


class FNXMultiShaderShaderNode(bpy.types.ShaderNodeCustomGroup):

    bl_name = constants.FNX_BLENDER__MULTI_SHADER_NODE_NAME
    bl_label = 'FNX Multi Shader'

    _SHADER_INPUT_TYPE = "NodeSocketShader"

    # Manage the node's sockets, adding additional ones when needed and removing those no longer required
    def __nodeinterface_setup__(self):

        current_num_inputs = len(self.node_tree.inputs)
        expected_num_inputs = self.num_inputs

        if expected_num_inputs > current_num_inputs:
            for _ in range(0, expected_num_inputs - current_num_inputs):
                self.node_tree.inputs.new(
                    FNXMultiShaderShaderNode._SHADER_INPUT_TYPE,
                    "Colorway index %d" % len(self.node_tree.inputs)
                )
        else:
            for _ in range(0, current_num_inputs - expected_num_inputs):
                self.node_tree.inputs.remove(self.node_tree.inputs[-1])

            value = min(self['colorways_index'], len(self.node_tree.inputs) - 1)
            self['colorways_index'] = value

    # Manage the internal nodes to perform the chained operation - clear all the nodes and build from scratch each time.
    def __nodetree_setup__(self):

        # Remove all links and all nodes that aren't Group Input or Group Output
        self.node_tree.links.clear()
        for node in self.node_tree.nodes:
            if not node.name in ['Group Input', 'Group Output']:
                self.node_tree.nodes.remove(node)

        # Start from Group Input and add nodes as required, chaining each new one to the previous level and the next input
        groupinput = self.node_tree.nodes['Group Input']

        previousnode = groupinput
        if self.num_inputs <= 1:
            # Special case <= 1 input --> link input directly to output
            self.node_tree.links.new(previousnode.outputs[0], self.node_tree.nodes['Group Output'].inputs[0])
        else:
            self.node_tree.links.new(
                self.node_tree.nodes['Group Input'].outputs[self.colorways_index],
                self.node_tree.nodes['Group Output'].inputs[0]
            )

    def update_operator(self, _context):
        self.__nodeinterface_setup__()
        self.__nodetree_setup__()

    def get_colorways_index(self):
        return self.get('colorways_index', 0)

    def set_colorways_index(self, value):

        if 0 <= value < len(self.node_tree.inputs):
            self['colorways_index'] = value

        self.__nodeinterface_setup__()
        self.__nodetree_setup__()

    num_inputs: bpy.props.IntProperty(name="Inputs", min=1, max=63, default=1, update=update_operator)
    colorways_index: bpy.props.IntProperty(name="Colorways", min=0, get=get_colorways_index, set=set_colorways_index)
    use_scene_colorways_index: bpy.props.BoolProperty(name="useColorways", default=False)

    # Setup the node - setup the node tree and add the group Input and Output nodes
    def init(self, _context):
        self.node_tree = bpy.data.node_groups.new('.' + self.bl_name, 'ShaderNodeTree')
        self.node_tree.nodes.new('NodeGroupInput')
        self.node_tree.nodes.new('NodeGroupOutput')

        self.node_tree.inputs.new(FNXMultiShaderShaderNode._SHADER_INPUT_TYPE, "Colorway index 0")
        self.node_tree.outputs.new(FNXMultiShaderShaderNode._SHADER_INPUT_TYPE, "Shader Out")

        self.node_tree.links.new(
            self.node_tree.nodes['Group Input'].outputs[0],
            self.node_tree.nodes['Group Output'].inputs[0]
        )

    # Draw the node components
    def draw_buttons(self, context, layout):
        row = layout.row()
        row.prop(self, 'num_inputs', text='Inputs')

        row = layout.row()
        row.prop(self, 'colorways_index', text='Colorways Index')

        row = layout.row()
        scn = context.scene
        row.label(text="Current FNX colorway index: %d" % scn.fnx_scene_state.colorway_index, icon="SCENE_DATA")

        row = layout.row()
        row.prop(self, 'use_scene_colorways_index', text='Use scene colorways index')

    # Copy
    def copy(self, node):
        self.node_tree = node.node_tree.copy()

    # Free (when node is deleted)
    def free(self):
        bpy.data.node_groups.remove(self.node_tree, do_unlink=True)


class FNXMenu(bpy.types.Menu):
    """FNX render menu."""

    bl_idname = "TOPBAR_MT_render_fnx_menu"
    bl_label = "FNX v1.7.1"
    bl_description = "FNX"

    def draw(self, _context):
        self.layout.separator()
        self.layout.operator(operators.FNXSubmitCurrentColorwaysOp.bl_idname)
        self.layout.operator(operators.FNXSubmitAllColorwaysOp.bl_idname)


def menu_func(self, _context):
    """"Add the FNX menu options to the 'Render' menu in the main toolbar."""
    self.layout.separator()
    self.layout.menu(FNXMenu.bl_idname)


class WM_UL_items(UIList):

    def draw_item(self, _context, layout, _data, item, _icon, _active_data, _active_propname, _index):
        row = layout.row()
        split = row.split(factor=0.8)
        c = split.column()
        icon = preview_collections['icons'][item.issue_type]
        c.prop(item, "name", text="", emboss=False, translate=False, icon_value=icon.icon_id)

        class_inst = getattr(validation, item.validator)
        if hasattr(class_inst, "fix"):
            split = split.split()
            c = split.column()
            c.operator("custom.run_validator_fix", text="Fix").validator_name = item.validator


class FNXMainPanel(Panel):
    """Creates a Panel in the Object properties window"""

    bl_label = "FNX"
    bl_idname = "SCENE_PT_layout"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "scene"

    def draw(self, context):
        layout = self.layout
        scn = context.scene

        row = layout.row()
        icon = preview_collections['icons']['fnx_logo']
        row.template_icon(icon_value=icon.icon_id, scale=3)

        # layout.operator(FNXCreateTemplateHierarchyOp.bl_idname)
        layout.operator(
            operators.FNXCreateGuideBoxOp.bl_idname,
            text="%s FNX guide box" % scn.fnx_scene_state.guide_box_state
        )

        layout.operator(operators.FNXConnectMultiShadersOp.bl_idname)
        layout.operator(operators.FNXAddColorwayOp.bl_idname)

        row = layout.row()
        row.template_list("WM_UL_items", "", scn, "issues", scn, "issue_index", rows=5)

        row = layout.row()
        if scn.fnx_scene_state.errors:
            row.label(text="Errors", icon="PANEL_CLOSE")
        else:
            row.label(text="No errors", icon="CHECKMARK")

        row = layout.row()
        row.operator(operators.FNXValidatorOp.bl_idname, text="Run checks", icon="NONE")

        layout.separator()

        row = layout.row()
        split = row.split(factor=0.3)
        col = split.column()
        col.label(text="Colorway Index")

        col = split.column()
        col.prop(scn.fnx_scene_state, "colorway_index", text="")

        row = layout.row()
        row.prop(scn.fnx_scene_state, "use_global_colorway_index", text="Use Scene Colorway Index")

        row = layout.row()

        fnx_icon = preview_collections['icons']['fnx_logo']
        row.operator(
            operators.FNXSubmitCurrentColorwaysOp.bl_idname,
            text="Submit Colorway %d to FNX" % scn.fnx_scene_state.colorway_index,
            icon_value=fnx_icon.icon_id
        )

        row = layout.row()
        row.operator(operators.FNXSubmitAllColorwaysOp.bl_idname, icon_value=fnx_icon.icon_id)


class FNXIssueProps(PropertyGroup):
    """FNX issue properties."""

    id: IntProperty()
    issue_type: StringProperty()
    validator: StringProperty()


class FNXSceneStateProps(PropertyGroup):
    """FNX scene state properties."""

    def get_colorway_index(self):
        return self.get('colorway_index', 0)

    def get_maximum_index(self, value):
        # Maximum colorway index should be maximum index on all FNX multi shader nodes
        shader_nodes = utils.get_fnx_multi_shaders()
        if len(shader_nodes) == 0:
            return 0

        num_node_colorway_indices = shader_nodes[0].num_inputs
        return min(value, num_node_colorway_indices - 1)

    def set_colorway_index(self, value):
        self['colorway_index'] = self.get_maximum_index(value)

        if not self.use_global_colorway_index:
            return

        for shader in utils.get_fnx_multi_shaders():
            shader.use_scene_colorways_index = True
            shader.set_colorways_index(self.colorway_index)

    def update_use_global(self, context):
        if not self.use_global_colorway_index:
            for shader in utils.get_fnx_multi_shaders():
                shader.use_scene_colorways_index = False
        else:
            self.set_colorway_index(context)

    errors: BoolProperty(
        description="Whether we have errors",
        default=False
    )

    warnings: BoolProperty(
        description="Whether we have warnings",
        default=False
    )

    guide_box_state: StringProperty(default="Create")

    colorway_index: IntProperty(
        description="The global colorway index",
        default=0,
        min=0,
        get=get_colorway_index,
        set=set_colorway_index
    )

    use_global_colorway_index: BoolProperty(
        description="Whether to use the global colorway index",
        default=False,
        update=update_use_global
    )


CLASSES = [
    # Panels
    FNXMainPanel,
    # Menus
    FNXMenu,
    # Properties
    FNXIssueProps,
    FNXSceneStateProps,
    # UILists
    WM_UL_items,
    # Shader nodes
    FNXMultiShaderShaderNode
]
"""FNX Blender class list."""

CUSTOM_SHADER_NODES = [
    ShaderNodeCategory("SH_NEW_CUSTOM", "Custom Nodes", items=[
        NodeItem("FNXMultiShaderShaderNode")
    ]),
]
"""Custom shader nodes."""


def register():
    """Register module and applicable classes."""

    pcoll = previews.new()

    # Path to the folder where the icons are
    my_icons_dir = os.path.join(os.path.dirname(__file__), "icons")

    # Get all .png files
    icons = [entry for entry in os.scandir(my_icons_dir) if entry.is_file() and entry.name.endswith('.png')]

    for icon in icons:
        name = os.path.splitext(icon.name)[0]
        pcoll.load(name, icon.path, 'IMAGE')

    preview_collections['icons'] = pcoll

    for cls in CLASSES:
        bpy.utils.register_class(cls)

    for cls in operators.OPERATOR_CLASSES:
        bpy.utils.register_class(cls)

    # Custom scene properties
    bpy.types.Scene.issues = CollectionProperty(type=FNXIssueProps)
    bpy.types.Scene.issue_index = IntProperty()
    bpy.types.Scene.fnx_scene_state = PointerProperty(type=FNXSceneStateProps)

    # Add FNX options to render menu
    bpy.types.TOPBAR_MT_render.append(menu_func)

    # Add FNX custom shader nodes
    register_node_categories("CUSTOM_NODES", CUSTOM_SHADER_NODES)

    # Remove temp bundles that are older than 1 week
    removed_bundles = pl_utils.remove_temp_files(constants.FNX_BLENDER__TMP_EXPORT_DIR_NAME, days_delta=7)
    if removed_bundles:
        LOGGER.info("FNX::Removed temporary files older than 7 days:")
        LOGGER.info(removed_bundles)


def unregister():
    """Unregister the module and applicable classes."""

    bpy.types.TOPBAR_MT_render.remove(menu_func)

    for cls in CLASSES:
        bpy.utils.unregister_class(cls)

    for cls in operators.OPERATOR_CLASSES:
        bpy.utils.unregister_class(cls)

    del bpy.types.Scene.issues
    del bpy.types.Scene.issue_index
    del bpy.types.Scene.fnx_scene_state

    previews.remove(preview_collections['icons'])

    unregister_node_categories('CUSTOM_NODES')


if __name__ == "__main__":
    register()
