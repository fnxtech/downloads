"""FNX Blender plugin exporter."""

# Python
import functools
from datetime import datetime
from pathlib import Path
import shutil

# Blender
import bpy

# FNX
from . import constants
from . import utils

# plugin-libs
from .plugin_libs.fnx_plugin_libs.logger import get_logger
from .plugin_libs.fnx_plugin_libs import utils as pl_utils
from .plugin_libs.fnx_plugin_libs import connect as pl_connect
from .plugin_libs.fnx_plugin_libs import exceptions as pl_exceptions


LOGGER = get_logger(__name__)

_RENDER_SETTINGS = {
    "image_settings.file_format": "PNG",
    "resolution_x": constants.FNX_BLENDER__THUMBNAIL_WIDTH,
    "resolution_y": constants.FNX_BLENDER__THUMBNAIL_WIDTH,
    "engine": 'CYCLES',
    "use_simplify": True,
    "simplify_subdivision_render": 0,
    "tile_x": 16,
    "tile_y": 16,
}

_CYCLES_RENDER_SETTINGS = {
    "samples": 16,
    "texture_limit_render": '128',
    "max_bounces": 4
}


def rsetattr(obj, attr, val):
    """Recursive setattr for setting nested dot notation attributes."""
    pre, _, post = attr.rpartition('.')
    return setattr(rgetattr(obj, pre) if pre else obj, post, val)


def rgetattr(obj, attr, *args):
    """Recursive getattr for getting nested dot notation attributes."""
    def _getattr(obj, attr):
        return getattr(obj, attr, *args)
    return functools.reduce(_getattr, [obj] + attr.split('.'))


class CustomRenderSetupContext:

    def __init__(self, scene_key):
        self._scene_key = scene_key

    def __enter__(self):
        self._camera = bpy.data.scenes[self._scene_key].camera
        self._file_path = bpy.data.scenes[self._scene_key].render.filepath

        self._render_settings = {}
        for k in _RENDER_SETTINGS.keys():
            self._render_settings[k] = rgetattr(bpy.data.scenes[self._scene_key].render, k)

        self._cycles_render_settings = {}
        for k in _CYCLES_RENDER_SETTINGS.keys():
            self._cycles_render_settings[k] = rgetattr(bpy.data.scenes[self._scene_key].cycles, k)

        # Add light for thumbnails
        bpy.ops.object.light_add(type='SUN')
        self._light_obj = bpy.context.active_object
        self._light_obj.data.energy = 2

    def __exit__(self, _type, _value, _traceback):
        bpy.data.scenes[self._scene_key].camera = self._camera
        bpy.data.scenes[self._scene_key].render.filepath = self._file_path

        for k, v in self._render_settings.items():
            rsetattr(bpy.data.scenes[self._scene_key].render, k, v)

        for k, v in self._cycles_render_settings.items():
            rsetattr(bpy.data.scenes[self._scene_key].cycles, k, v)

        # Remove light for thumbnails
        bpy.ops.object.delete({"selected_objects": [self._light_obj]})


def render_camera_views(output_dir: Path):
    """
    Render custom camera views and generate dictionary with camera transformation data.

    Blender custom camera dictionary will have the following format:

        {
          "name": "FNX_CAMERA__test",
          "image_path": "C:\\Users\\DOMINI~1\\AppData\\Local\\Temp\\fnx_blender_export\\2020_10_30_09_11_27\\thumbnails\\FNX_CAMERA__test.png",
          "fov": 0.6911112070083618,
          "camera_transform": {
            "matrix": [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0]
          }
        }

    Args:
        output_dir: the output directory for the export

    Returns:
        custom camera dictionary

    """

    # Make thumbnails directory
    thumbnails_dir = output_dir / constants.FNX_BLENDER__THUMBNAILS_DIR_NAME
    thumbnails_dir.mkdir(exist_ok=True)

    cameras = []
    for camera in utils.get_fnx_scene_cameras():

        scene_key = bpy.data.scenes.keys()[0]

        thumbnail_base_path = str(thumbnails_dir / camera.name)

        # Set Scenes camera and output filename
        with CustomRenderSetupContext(scene_key):
            bpy.data.scenes[scene_key].camera = camera
            bpy.data.scenes[scene_key].render.filepath = thumbnail_base_path

            for k, v in _RENDER_SETTINGS.items():
                rsetattr(bpy.data.scenes[scene_key].render, k, v)

            for k, v in _CYCLES_RENDER_SETTINGS.items():
                rsetattr(bpy.data.scenes[scene_key].cycles, k, v)

            # Render Scene and store the scene
            bpy.ops.render.render(write_still=True)

        # Convert camera transform to formatted string
        matrix_flat_list = [item for sublist in camera.matrix_world.row for item in sublist]

        camera_dict = {
            "name": camera.name,
            "image_path": thumbnail_base_path + ".png",
            "fov": camera.data.angle,
            "camera_transform": {
                "matrix": matrix_flat_list
            }
        }
        cameras.append(camera_dict)

    return cameras


def export_bundle(output_dir: Path, colorway_indices) -> Path:
    """
    Export a Blender bundle for the render service.

    Args:
        output_dir:
        colorway_indices:

    Returns:

    """

    # Render camera views and collect cameras' data
    LOGGER.info("Rendering custom camera thumbnails...")

    custom_cameras = render_camera_views(output_dir=output_dir)

    # Generate config

    scene_data = {
        "garment_name": constants.FNX_BLENDER__GARMENT_COLLECTION_NAME,
        "num_colorways": len(colorway_indices),
        "serialized_colorways": colorway_indices,
        "avatar_name": constants.FNX_BLENDER__AVATAR_COLLECTION_NAME,  # TODO: Handle multiple avatars
    }

    dcc_dict = {
        "name": "Blender",
        "version": bpy.app.version_string
    }

    project_path = Path(bpy.context.blend_data.filepath)
    project_name = project_path.stem

    fnxc_config_file = pl_utils.export_submit_config(
        output_dir,
        project_path,
        project_name,
        custom_cameras,
        dcc_dict,
        scene_data
    )

    # Make sure all the texture files are packed in the scene file
    bpy.ops.file.pack_all()

    # Save Blender file into bundle
    temp_blender_filepath = Path(output_dir) / bpy.path.ensure_ext(project_name, ".blend")
    bpy.ops.wm.save_as_mainfile(filepath=temp_blender_filepath.as_posix(), copy=True)

    return fnxc_config_file


def generate_and_submit_bundle(colorway_indices):
    """

    Args:
        colorway_indices:

    Returns:

    """
    connect_status = pl_connect.get_connect_status()
    if connect_status.error:
        msg = (f"{connect_status.message}.\n"
               f"Make sure it's running in the background and try again.")
        raise Exception(msg)

    output_dir = pl_utils.create_output_temp_dir(constants.FNX_BLENDER__TMP_EXPORT_DIR_NAME)

    fnxc_config = export_bundle(
        output_dir,
        colorway_indices
    )

    if not fnxc_config:
        # Cleanup
        shutil.rmtree(output_dir)
        raise pl_exceptions.NoConfigException()
    
    try:
        pl_connect.launch_session(asset_path=fnxc_config)
    except Exception as ex:
        shutil.rmtree(output_dir)
        raise pl_exceptions.SubmitException(ex)
