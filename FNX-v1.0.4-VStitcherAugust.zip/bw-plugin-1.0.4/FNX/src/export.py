import datetime
import json
import re
import shutil
import sys
import tempfile
import time
from logger import get_logger
from os import path, makedirs, rmdir
from pathlib import Path
sys.path.insert(0, path.abspath(__file__))
import BwApi

from export_u3m import export_u3m
from utils import (
    current_time,
    get_avatar_name,
    fnx_handle_error,
    zip_dir,
    sanitize_name,
    remove_control_characters,
    INVCHARS_PATTERN,
    FnxException
)

LOGGER = get_logger(__name__)
FNX_SUBMIT_CONFIG_FILE = "fnx.submit.config"

def export_succeed():
    last_error = BwApi.GetLastError()
    print("ERROR: Exporting failed -- {}".format(last_error))
    if last_error != BwApi.BW_API_ERROR_SUCCESS:

        if last_error == BwApi.BW_API_ERROR_NO_SNAPSHOT_AVAILABLE:
            BwApi.WndMessageBox("No snapshot is loaded. The avatar should be dressed first.", BwApi.BW_API_MB_OK)

        return False

    return True


def get_colorway_names(garment_id, current_colorway=False):
    """Get all colorway names for the given garment.

    :param garment_id: id of the current garment
    :type garment_id: int
    :param current_colorway: Whether to get only the current colorway
                             or all colorways.
    :type current_colorway: bool
    :rtype: generator object
    :return: Generator yielding colorway names
    """
    if current_colorway:
        colorway_ids = [BwApi.ColorwayCurrentGet(garment_id)]
    else:
        colorway_ids = list(BwApi.GarmentColorwayIds(garment_id))

    for cid in colorway_ids:
        yield BwApi.ColorwayNameGet(garment_id, cid)


@fnx_handle_error
def export_fbx(garment_id, output_dir=None, colorway_ids=(),
               include_avatar=True, binary=True):
    """Export garment geometry as FBX in a temp location

    :param garment_id: id of the current garment
    :type garment_id: int
    :rtype: str
    :return: path to the exported FBX file
    """
    if output_dir:
        temp_location = Path(output_dir) / 'FBX_out'
    else:
        temp_location = Path(tempfile.gettempdir()) / 'export_fbx' / current_time()

    if not temp_location.exists():
        temp_location.mkdir(parents=True, exist_ok=True)

    project_name = BwApi.GarmentNameGet(garment_id)
    fbx_file_path = temp_location / f"{project_name}.fbx"
    export_settings = {
        "3d_format": "autodesk_fbx",
        "version": "FBX201800",
        "type": "binary" if binary else "ascii",
        "path": str(fbx_file_path),
        "up_axis": "y",
        "scale": 1,
        "use_pattern_pieces_names": True,
        "layout": {
            "layout_type": "native_uv",
            "image": "combined_image",
            "dpi": 100,
            "use_material_names": True,
            "embed_offset": True
        },
        "include_avatar": include_avatar
    }

    if len(colorway_ids) > 1:
        multipack = []
        for colorway_id in colorway_ids:
            multipack.append({
                "colorway_id": int(colorway_id),
                "position": [0, 0, 0]
            })

        export_settings['layout']["multipack"] = multipack

    BwApi.RenderExport3DObject(garment_id, json.dumps(export_settings))

    return export_settings


@fnx_handle_error
def export_obj(garment_id, output_dir=None, include_avatar=True):
    """Export garment geometry as OBJ in a temp location

    :param garment_id: id of the current garment
    :type garment_id: int
    :param output_dir: Directory to save the obj file/textures
    :type output_dir: str
    :param include_avatar: Whether to export OBJ with avatar geometry included.
    :type include_avatar: bool
    :rtype: str
    :return: path to the exported OBJ file
    """
    if output_dir:
        temp_location = path.join(output_dir, 'OBJ_out')
    else:
        temp_location = path.join(tempfile.gettempdir(),
                                'fnx_export_obj',
                                current_time())

    if not path.exists(temp_location):
        makedirs(temp_location)

    obj_file_path = path.join(temp_location, '{}.obj'.format(current_time()))
    export_settings = {
        "3d_format": "obj",
        "path": obj_file_path,
        "up_axis": "y",
        "scale": 0.01,
        "use_pattern_pieces_names": True,
        "layout": {
            "layout_type": "layout_uv",
            "export_inside": True,
            "piece": "per_piece",
            "dpi": 100,  # between 50 - 400
            "embed_offset": True,
        },
        "include_avatar": include_avatar,
    }

    BwApi.RenderExport3DObject(garment_id, json.dumps(export_settings))

    return export_settings

def init_submit_config(garment_id, base_path):
    plugin = {}
    plugin_json = Path(__file__).parents[1]/"plugin.json"
    with open(plugin_json, 'r') as pjson:
        plugin = json.load(pjson)

    project_name = BwApi.GarmentNameGet(garment_id)
    project_path = Path(BwApi.GarmentPathGet(garment_id))
    if project_path.name == "__bwsqlitefoler__":
        project_path = project_path.parent

    config = {
        "file": str(project_path),
        "project_name": project_name,
        "dcc": "BWV",
        "plugin": plugin,
        "job_options": {},
        "scene_data": {}
    }

    cfg_path = Path(base_path)/FNX_SUBMIT_CONFIG_FILE
    with open(cfg_path, "w") as fp:
        json.dump(config, fp, indent=4)

    return config, cfg_path

def get_scene_data(garment_id, colorway_ids, include_avatar):
    try:
        camera_data = BwApi.EnvironmentCameraGet()
    except:
        camera_data = {}

    camera_data = json.loads(camera_data)
    scene_data = {
        'camera': camera_data,
    }
    scene_data['garment_name'] = BwApi.GarmentNameGet(garment_id)
    scene_data['num_colorways'] = len(colorway_ids)
    serialized_colorways = []
    for colorway_id in colorway_ids:
        colorway_name = BwApi.ColorwayNameGet(garment_id, colorway_id)
        # sanitizing the name from any character that would cause issue in
        # file name
        colorway_name = colorway_name.replace('/', '')
        serialized_colorways.append(f"{colorway_id}_{colorway_name}")

    scene_data['serialized_colorways'] = serialized_colorways
    scene_data['colorway_id'] = BwApi.ColorwayCurrentGet(garment_id)

    avatar_name = get_avatar_name()
    scene_data['avatar_name'] = avatar_name
    scene_data['current_avatar'] = BwApi.AvatarCurrentGet()

    return scene_data



def export_bundle(garment_id, output_dir, colorway_ids=None, as_zip=False, include_avatar=False) -> Path:
    """Export the garment geo and textures for bw-to-blender render service."""
    LOGGER.info(' Exporting FBX and U3M '.center(80, "*"))
    colorway_ids = colorway_ids or (BwApi.ColorwayCurrentGet(garment_id),)
    ################ Export OBJ ################
    try:
        export_geo_settings = export_fbx(garment_id=garment_id,
                                         output_dir=output_dir,
                                         colorway_ids=colorway_ids,
                                         include_avatar=include_avatar,
                                         binary=True)
    except FnxException as export_error:
        BwApi.WndMessageBox(str(export_error), BwApi.BW_API_MB_OK)
        return

    fbx_path = Path(export_geo_settings['path'])
    assert fbx_path.exists(), "FBX geometry and textures failed to export."
    # Make FBX path relative.
    export_geo_settings['path'] = str(fbx_path.relative_to(output_dir))

    config, cfg_path = init_submit_config(garment_id, output_dir)
    config['geo_export'] = export_geo_settings

    # Extra scene info
    config['scene_data'] = get_scene_data(garment_id, colorway_ids, include_avatar)

    # Update the config file.
    with open(cfg_path, "w") as fp:
        json.dump(config, fp, indent=4)

    # Write config file that drives FNX Connect
    fnxc_config = dict()
    fnxc_config["num_colorways"] = len(colorway_ids)
    fnxc_config["data"] = output_dir
    fnxc_config["label"] = config["project_name"]
    fnxc_config["additional_files"] = {"beproduct_render_blender": [config["file"]]}

    fnxc_config_file = Path(output_dir) / 'fnxc.config'
    with open(fnxc_config_file, 'w') as filehandle:
        json.dump(fnxc_config, filehandle, indent=2)

    if as_zip:
        zip_file = str(Path(output_dir)/"export_bundle.zip")
        zip_dir(output_dir, zip_file)
        return Path(zip_file)
    else:
        return Path(fnxc_config_file)
