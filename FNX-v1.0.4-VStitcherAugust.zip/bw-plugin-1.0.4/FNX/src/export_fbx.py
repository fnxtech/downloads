import json
import sys
import tempfile
from os import path, makedirs

import BwApi

sys.path.insert(0, path.abspath(__file__))

from logger import get_logger
from utils import current_time

LOGGER = get_logger(__name__)


def export_fbx(garment_id):
    """Export garment geometry as FBX in a temp location

    :param garment_id: id of the current garment
    :type garment_id: int
    :rtype: str
    :return: path to the exported FBX file
    """
    temp_location = path.join(tempfile.gettempdir(),
                              'export_fbx',
                              current_time())
    if not path.exists(temp_location):
        makedirs(temp_location)

    fbx_file_path = path.join(temp_location, '{}.fbx'.format(garment_id))

    export_settings = {
        "3d_format": "autodesk_fbx",
        "version": "FBX201800",
        "type": "binary",
        "path": fbx_file_path,
        "up_axis": "z",
        "scale": 1,
        "use_pattern_pieces_names": False,
        "piece": "all_pieces_bounding_box",  # all_pieces_square"
        "layout": {
            "layout_type": "native_uv",
            "image": "original_image",  # other option "combined_image"
            "dpi": 400,  # between 50 - 400
            "use_material_names": True,
            "embed_offset": True,
        },
        "include_avatar": True,
    }

    # TODO: it needs error handling
    BwApi.RenderExport3DObject(garment_id, json.dumps(export_settings))

    return fbx_file_path
