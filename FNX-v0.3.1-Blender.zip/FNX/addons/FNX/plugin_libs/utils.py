# Python
import json
import os
import shutil
import subprocess
import tempfile
from datetime import datetime, timedelta

try:
    from pathlib import Path
except ImportError:
    # Python 2.x compatibility library
    # N.B. We can pip install pathlib2 but some DCC's (e.g. Modo) have closed Python so cannot
    from .externals.pathlib2 import Path

# from typing import Generator

# plugins-libs
from . import constants
from . import exceptions
from .logger import get_logger

LOGGER = get_logger(__name__)

_CONFIG_VERSION = 2
"""Use a config version for Connect."""


def get_temp_dir(temp_dir_name):
    temp_dir = Path(tempfile.gettempdir()) / temp_dir_name

    return temp_dir


def create_output_temp_dir(temp_dir_name, name=None):
    dir_name = name or current_time()
    out_dir = get_temp_dir(temp_dir_name) / dir_name
    out_dir.mkdir(exist_ok=True, parents=True)
    return out_dir


def get_temp_bundles(temp_dir_name, days_delta=0):
    """Get the paths of bundles exported to the temporary folder
    that are older than the number of days given.

    Args:
        days_delta: Minimum number of elapsed days since folder was created.
    Returns:
        Generator: Yields Path objects.
    """
    temp_dir = get_temp_dir(temp_dir_name)
    if not temp_dir.exists():
        return

    for bundle_path in temp_dir.iterdir():
        created = os.path.getctime(bundle_path)
        age = datetime.now() - datetime.fromtimestamp(created)
        if age > timedelta(days=days_delta):
            yield bundle_path


def remove_temp_files(temp_dir_name, days_delta=0):
    """Removes bundles which were exported the temporary folder
    that are older than the maximum given age.

    Args:
        days_delta: Minimum number of elapsed days since folder was created.

    Returns:
        [Path]: List of removed bundle paths.
    """
    removed_bundles = []
    for bundle_path in get_temp_bundles(temp_dir_name, days_delta):
        shutil.rmtree(bundle_path)
        removed_bundles.append(bundle_path)

    return removed_bundles


def current_time(pretty=False):
    """ Return current date and time
    :return: representation of current time and date, Ex: 2017_05_18_11_01_48
    :rtype: str
    """

    if pretty:
        return datetime.now().strftime('%m/%d/%Y - %H:%M:%S')

    return datetime.now().strftime('%Y_%m_%d_%H_%M_%S')


def run_submitter(asset_path, session_id=None, is_batch=False, dry_run=False):
    """Run the FNX Connect app with the provided asset path.

    Args:
      session_id (str): ID of the submission session.
      asset_path (Path): The asset path, particulary the fnxc.config file.
      is_batch (bool): Whether the jobs are submitted in batch or as a single job.
      dry_run (bool): Print out the full command. Default runs the command.

    Returns:
      Path: The path to the file created in the conversion.
    """
    submitter_exe_path = find_submitter()
    cmd = [
        str(submitter_exe_path),
        "bundle_render_submission",
        str(asset_path)
    ]

    if session_id:
        cmd.extend(["--session=%s" % session_id])

    if is_batch:
        cmd.append("--batch")

    if dry_run:
        cmd_str = ' '.join(cmd)
        LOGGER.debug(cmd_str)
        return cmd_str

    subprocess.Popen(cmd, shell=False)


def find_submitter():
    """Find the Submitter executable by checking the environment variable FNX_SUBMITTER_APP first, then PATH, then
    defaults to /usr/local/blender/blender.

    Throws if it can't find the file.
    """
    submitter_exe_path = os.environ.get(constants.FNX_SUBMITTER_APP_ENV_VAR)
    if not submitter_exe_path:
        raise exceptions.SubmitterDoesNotExistException()

    if not Path(submitter_exe_path).exists():
        raise exceptions.SubmitterExeDoesNotExistException(submitter_exe_path)

    return Path(submitter_exe_path)


def export_submit_config(output_dir, project_path, project_name, custom_cameras, dcc_dict, scene_data,
                         beproduct_render=False, geo_export=None):
    """
    Generate and write config file that drives FNX Connect.

    Args:
        cameras (dict): custom cameras
        output_dir (Path): the output directory
        colorway_indices (list): list of colorway indices

    Returns:

    """
    # Load plugin info - check parents
    plugin_json = None
    for idx in range(0, 3):
        plugin_json = Path(__file__).parents[idx] / "plugin.json"
        if plugin_json.exists():
            break

    if not plugin_json:
        raise exceptions.FNXException("Could not locate plugin.json file.")

    with open(str(plugin_json), "r") as pjson:
        plugin_dict = json.load(pjson)

    fnxc_config = {
        "config_version": _CONFIG_VERSION,
        "custom_cameras": custom_cameras,
        "data": str(output_dir),
        "project_file": project_path.as_posix(),
        "project_name": project_name,
        "dcc": dcc_dict,
        "plugin": plugin_dict,
        "scene_data": scene_data
    }

    if beproduct_render:
        fnxc_config["additional_files"] = {"beproduct_render_blender": [project_path.as_posix()]}

    if geo_export:
        fnxc_config["geo_export"] = geo_export

    fnxc_config_file = output_dir / constants.FNX_CONFIG_FILE
    with open(str(fnxc_config_file), "w") as file_handle:
        json.dump(fnxc_config, file_handle, indent=2)

    return fnxc_config_file
