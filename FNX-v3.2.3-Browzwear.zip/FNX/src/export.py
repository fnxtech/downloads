# Python
import json
from pathlib import Path

# Browzwear
import BwApi

# FNX
from .utils import (
    get_avatar_name,
    get_dcc_version,
    fnx_handle_error,
    render_camera_views,
    is_alvanon_avatar,
    get_project_path
)

# plugin-libs
from .plugin_libs.logger import get_logger
from .plugin_libs import exceptions as pl_exceptions
from .plugin_libs import utils as pl_utils

LOGGER = get_logger(__name__)

_DEFAULT_CAMERAS = set(["Top", "Bottom", "Left", "Right", "Front", "Back"])


@fnx_handle_error
def export_vrscene(garment_id: str, output_dir: Path) -> dict:
    """Export vrscene and images for Vray render jobs.

    Returns:
        dict: setttings used in export API call
    """
    project_name = BwApi.GarmentNameGet(garment_id)
    vrscene_file_path = output_dir / f"{project_name}.vrscene"

    export_settings = {
        "3d_format": "vrscene",
        "render_quality": "medium",  # TODO: rethink this.
        "dpi": 200,  # TODO rethink this
        "path": vrscene_file_path.as_posix(),
        "use_gpu": False,
        "include_avatar": True
    }

    BwApi.RenderExport3DObject(garment_id, json.dumps(export_settings))
    LOGGER.debug(f"Exported vrscene: {export_settings}")
    return export_settings


def export_fbx(garment_id: str, output_dir: Path, colorway_ids=(), include_avatar=True, binary=True) -> dict:
    """
    Export garment geometry as FBX in a temp location

    :param garment_id: id of the current garment
    :type garment_id: int
    :rtype: str
    :return: path to the exported FBX file
    """
    project_name = BwApi.GarmentNameGet(garment_id)
    fbx_file_path = output_dir / f"{project_name}.fbx"
    export_settings = {
        "3d_format": "browzwear_pbr_fbx",
        "version": "FBX201800",
        "type": "binary" if binary else "ascii",
        "path": str(fbx_file_path),
        "up_axis": "y",
        "scale": 1,
        "use_pattern_pieces_names": True,
        "layout": {
            "layout_type": "native_uv",
            "image": "combined_image",
            "dpi": 100,
            "use_material_names": True,
            "embed_offset": True
        },
        "include_avatar": include_avatar
    }
    # If we're dealing with an Alvanon avatar, match garment to avatar
    if is_alvanon_avatar() and include_avatar:
        export_settings["match_garment"] = True

    if len(colorway_ids) > 1:
        multipack = []
        for colorway_id in colorway_ids:
            multipack.append({
                "colorway_id": int(colorway_id),
                "position": [0, 0, 0]
            })

        export_settings['layout']["multipack"] = multipack

    BwApi.RenderExport3DObject(garment_id, json.dumps(export_settings))

    return export_settings


def get_scene_data(garment_id, colorway_ids):

    serialized_colorways = []
    for colorway_id in colorway_ids:
        colorway_name = BwApi.ColorwayNameGet(garment_id, colorway_id)
        # sanitizing the name from any character that would cause issue in
        # file name
        colorway_name = colorway_name.replace('/', '')
        serialized_colorways.append(f"{colorway_id}_{colorway_name}")

    is_alvanon = is_alvanon_avatar()
    scene_data = {
        'garment_name': BwApi.GarmentNameGet(garment_id),
        'num_colorways': len(colorway_ids),
        'serialized_colorways': serialized_colorways,
        'colorway_id': BwApi.ColorwayCurrentGet(garment_id),
        'avatar_name': get_avatar_name(alvanon=is_alvanon),
        'avatar_pose': BwApi.AvatarPoseCurrentGet(),
        'current_avatar': BwApi.AvatarCurrentGet()
    }

    return scene_data


def export_bundle(garment_id: str, output_dir: Path, colorway_ids=None, include_avatar=False) -> Path:
    """Export the garment geo and textures for bw-to-blender render service."""

    # Render camera views and collect cameras' data
    LOGGER.info(' Rendering custom camera thumbnails '.center(80, "*"))
    custom_cameras = []
    all_cameras = set(BwApi.EnvironmentCameraViews())
    camera_views = list(all_cameras.difference(_DEFAULT_CAMERAS))
    if camera_views and not is_alvanon_avatar():
        thumbnails_dir = output_dir / "thumbnails"
        thumbnails_dir.mkdir(exist_ok=True)
        render_params = render_camera_views(out_path=thumbnails_dir,
                                            garment_id=garment_id,
                                            camera_views=camera_views,
                                            width=150,
                                            height=150,
                                            include_avatar=include_avatar)

        captures = render_params["captures"]
        for capture in captures:
            camera = dict()
            camera["name"] = capture["camera_name"]
            camera["image_path"] = capture["path"]
            camera_data = capture["camera"]
            camera["fov"] = camera_data.pop("fov")
            camera["camera_transform"] = camera_data
            custom_cameras.append(camera)

    # Export geometry and textures
    colorway_ids = colorway_ids or (BwApi.ColorwayCurrentGet(garment_id),)
    LOGGER.info(' Exporting FBX '.center(80, "*"))
    fbx_out_path = output_dir / "FBX_out"
    fbx_out_path.mkdir(parents=True, exist_ok=True)
    try:
        export_geo_settings = export_fbx(
            garment_id=garment_id,
            output_dir=fbx_out_path,
            colorway_ids=colorway_ids,
            include_avatar=include_avatar,
            binary=True
        )
    except pl_exceptions.FNXException as export_error:
        BwApi.WndMessageBox(str(export_error), BwApi.BW_API_MB_OK)
        return None

    fbx_path = Path(export_geo_settings['path'])
    if not fbx_path.exists():
        raise pl_exceptions.FNXException("FBX geometry and textures failed to export.")

    # Make FBX path relative.
    export_geo_settings['path'] = str(fbx_path.relative_to(output_dir))

    project_name = BwApi.GarmentNameGet(garment_id)
    project_path = get_project_path(garment_id)

    fnxc_config_file = pl_utils.export_submit_config(
        output_dir,
        project_path,
        project_name,
        custom_cameras,
        get_dcc_version(),
        get_scene_data(garment_id, colorway_ids),
        beproduct_render=True,
        geo_export=export_geo_settings
    )

    return fnxc_config_file
