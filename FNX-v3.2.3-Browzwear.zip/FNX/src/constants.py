FNX_BWV__TMP_EXPORT_DIR_NAME = "fnx_vstitcher_export"
"""FNX Browzwear temporary directory name."""
